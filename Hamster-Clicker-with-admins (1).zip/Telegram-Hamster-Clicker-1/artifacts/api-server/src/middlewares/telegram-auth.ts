import { createHmac, timingSafeEqual } from "node:crypto";
import type { RequestHandler } from "express";
import { syncTelegramPlayer } from "../lib/game";

export type TelegramIdentity = {
  telegramId: string;
  username: string | null;
  firstName: string;
  lastName: string | null;
  startParam: string | null;
};

declare global {
  namespace Express {
    interface Request {
      telegramUser?: TelegramIdentity;
      telegramAdmin?: boolean;
    }
  }
}

function validateTelegramInitData(raw: string): TelegramIdentity | null {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return null;

  try {
    const params = new URLSearchParams(raw);
    const providedHash = params.get("hash");
    const authDate = Number(params.get("auth_date"));
    if (!providedHash || !/^[a-f0-9]{64}$/i.test(providedHash)) return null;
    if (!Number.isFinite(authDate)) return null;

    const now = Math.floor(Date.now() / 1000);
    if (authDate > now + 60 || now - authDate > 60 * 60 * 24) return null;

    const checkString = [...params.entries()]
      .filter(([key]) => key !== "hash")
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([key, value]) => `${key}=${value}`)
      .join("\n");
    const secretKey = createHmac("sha256", "WebAppData").update(token).digest();
    const expectedHash = createHmac("sha256", secretKey)
      .update(checkString)
      .digest();
    const receivedHash = Buffer.from(providedHash, "hex");
    if (
      receivedHash.length !== expectedHash.length ||
      !timingSafeEqual(receivedHash, expectedHash)
    ) {
      return null;
    }

    const userValue = params.get("user");
    if (!userValue) return null;
    const user = JSON.parse(userValue) as {
      id?: number | string;
      username?: string;
      first_name?: string;
      last_name?: string;
    };
    if (user.id == null || !/^\d+$/.test(String(user.id))) return null;

    return {
      telegramId: String(user.id),
      username: user.username ?? null,
      firstName: user.first_name?.slice(0, 128) || "Hamster",
      lastName: user.last_name?.slice(0, 128) ?? null,
      startParam: params.get("start_param"),
    };
  } catch {
    return null;
  }
}

function developmentIdentity(requestedId: string | undefined): TelegramIdentity {
  const id = requestedId && /^\d{1,32}$/.test(requestedId) ? requestedId : "900000001";
  return {
    telegramId: id,
    username: "preview_player",
    firstName: "Игрок",
    lastName: "Hamster",
    startParam: null,
  };
}

export const requireTelegramAuth: RequestHandler = async (req, res, next): Promise<void> => {
  const rawInitData = req.header("x-telegram-init-data");
  const identity = rawInitData ? validateTelegramInitData(rawInitData) : null;

  if (identity) {
    try {
      await syncTelegramPlayer(identity);
      req.telegramUser = identity;
      req.telegramAdmin = (process.env.TELEGRAM_ADMIN_IDS ?? "")
        .split(",")
        .map((value) => value.trim())
        .filter(Boolean)
        .includes(identity.telegramId);
      next();
    } catch (error) {
      req.log.error({ err: error }, "Failed to sync authenticated Telegram player");
      res.status(503).json({ error: "Не удалось загрузить игровой профиль" });
    }
    return;
  }

  if (process.env.NODE_ENV === "development") {
    try {
      const devIdentity = developmentIdentity(req.header("x-dev-telegram-id"));
      await syncTelegramPlayer(devIdentity);
      req.telegramUser = devIdentity;
      req.telegramAdmin = true;
      next();
    } catch (error) {
      req.log.error({ err: error }, "Failed to sync development Telegram player");
      res.status(503).json({ error: "Не удалось загрузить игровой профиль" });
    }
    return;
  }

  res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
};

export const requireTelegramAdmin: RequestHandler = (req, res, next): void => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Требуется подтверждённый аккаунт Telegram" });
    return;
  }
  if (!req.telegramAdmin) {
    res.status(403).json({ error: "Доступ только для администратора проекта" });
    return;
  }
  next();
};
