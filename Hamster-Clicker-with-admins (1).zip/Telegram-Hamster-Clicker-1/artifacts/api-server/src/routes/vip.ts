import { eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { CreateVipInvoiceResponse } from "@workspace/api-zod";
import { db, hamsterPlayers } from "@workspace/db";
import { requireTelegramAuth } from "../middlewares/telegram-auth";
import { createVipInvoice } from "../lib/telegram";

const router: IRouter = Router();
router.use(requireTelegramAuth);

router.post("/vip/invoice", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }
  if (!process.env.TELEGRAM_BOT_TOKEN) {
    res.status(503).json({ error: "Платежи Telegram Stars не настроены" });
    return;
  }
  try {
    const [player] = await db
      .select({ vipExpiresAt: hamsterPlayers.vipExpiresAt })
      .from(hamsterPlayers)
      .where(eq(hamsterPlayers.telegramId, req.telegramUser.telegramId))
      .limit(1);
    if (player?.vipExpiresAt && player.vipExpiresAt > new Date()) {
      res.status(409).json({ error: "VIP уже активен" });
      return;
    }
    const invoice = await createVipInvoice(req.telegramUser.telegramId);
    res.json(
      CreateVipInvoiceResponse.parse({
        invoiceUrl: invoice.invoiceUrl,
        durationDays: 30,
        priceStars: 300,
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Failed to create a Telegram Stars invoice");
    res.status(503).json({ error: "Не удалось создать счёт Telegram Stars" });
  }
});

export default router;
