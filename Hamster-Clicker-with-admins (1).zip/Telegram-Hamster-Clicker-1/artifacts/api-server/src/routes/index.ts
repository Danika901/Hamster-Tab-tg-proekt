import { Router, type IRouter } from "express";
import contestsRouter from "./contests";
import gameRouter from "./game";
import healthRouter from "./health";
import shopRouter from "./shop";
import socialRouter from "./social";
import telegramWebhookRouter from "./telegram-webhook";
import vipRouter from "./vip";

const router: IRouter = Router();

router.use(healthRouter);
router.use(telegramWebhookRouter);
router.use(gameRouter);
router.use(shopRouter);
router.use(socialRouter);
router.use(contestsRouter);
router.use(vipRouter);

export default router;
