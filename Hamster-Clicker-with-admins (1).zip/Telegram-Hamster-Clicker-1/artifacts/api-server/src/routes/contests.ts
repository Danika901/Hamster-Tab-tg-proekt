import { randomInt } from "node:crypto";
import {
  and,
  count,
  desc,
  eq,
  gt,
  inArray,
  lte,
} from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  ConfirmContestSeriesBody,
  ConfirmContestSeriesResponse,
  CreateContestBody,
  CreateContestResponse,
  GetAdminContestsResponse,
  GetAdminContestsResponseItem,
  GetAdminOverviewResponse,
  GetContestCalendarResponse,
  GetContestsResponse,
  GetContestsResponseItem,
  JoinContestBody,
  JoinContestParams,
  JoinContestResponse,
  RunContestActionBody,
  RunContestActionParams,
  RunContestActionResponse,
  UpdateCalendarDayBody,
  UpdateCalendarDayParams,
  UpdateCalendarDayResponse,
  UpdateContestBody,
  UpdateContestParams,
  UpdateContestResponse,
} from "@workspace/api-zod";
import {
  db,
  hamsterAppSettings,
  hamsterCalendarEntries,
  hamsterContestEntries,
  hamsterContests,
  hamsterPlayers,
  hamsterReferrals,
} from "@workspace/db";
import { requireTelegramAdmin, requireTelegramAuth } from "../middlewares/telegram-auth";
import {
  sendContestPost,
  sendContestResults,
  telegramCall,
} from "../lib/telegram";
import { logger } from "../lib/logger";

const router: IRouter = Router();
const admin: IRouter = Router();
router.use(requireTelegramAuth);
admin.use(requireTelegramAdmin);

const seriesSettingKey = "contest-series";
const defaultTimeZone = "Europe/Warsaw";
const dayMs = 24 * 60 * 60 * 1000;
const publishing = new Set<string>();
const retryAfter = new Map<string, number>();

function isUuid(value: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Не удалось выполнить операцию";
}

function dateOnlyInZone(date: Date, timeZone: string): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const value = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${value.year}-${value.month}-${value.day}`;
}

function calendarDateOffset(start: string, offset: number): string {
  const date = new Date(`${start}T00:00:00.000Z`);
  date.setUTCDate(date.getUTCDate() + offset);
  return date.toISOString().slice(0, 10);
}

function toPublicContest(
  contest: typeof hamsterContests.$inferSelect,
  participants: number,
  joined: boolean,
) {
  return GetContestsResponseItem.parse({
    id: contest.id,
    title: contest.title,
    description: contest.description,
    type: contest.type,
    status: contest.status,
    prize: contest.prize,
    winnersCount: contest.winnersCount,
    startsAt: contest.startsAt.toISOString(),
    endsAt: contest.endsAt.toISOString(),
    timeZone: contest.timeZone,
    participants,
    joined,
    conditions: contest.conditions,
    vipOnly: contest.vipOnly,
    requiresSubscription: contest.requiresSubscription,
    quizQuestion: contest.quizQuestion,
    quizOptions: contest.quizOptions,
    imageUrl: contest.imageUrl,
    winners: contest.winners,
  });
}

function toAdminContest(
  contest: typeof hamsterContests.$inferSelect,
  participants: number,
  joined: boolean,
) {
  return GetAdminContestsResponseItem.parse({
    ...toPublicContest(contest, participants, joined),
    quizCorrectOption: contest.quizCorrectOption,
  });
}

async function withParticipation(
  contests: (typeof hamsterContests.$inferSelect)[],
  telegramId: string,
) {
  if (contests.length === 0) return [];
  const ids = contests.map((contest) => contest.id);
  const [counts, mine] = await Promise.all([
    db
      .select({ contestId: hamsterContestEntries.contestId, total: count() })
      .from(hamsterContestEntries)
      .where(inArray(hamsterContestEntries.contestId, ids))
      .groupBy(hamsterContestEntries.contestId),
    db
      .select({ contestId: hamsterContestEntries.contestId })
      .from(hamsterContestEntries)
      .where(
        and(
          inArray(hamsterContestEntries.contestId, ids),
          eq(hamsterContestEntries.telegramId, telegramId),
        ),
      ),
  ]);
  const countById = new Map(counts.map((item) => [item.contestId, Number(item.total)]));
  const joinedIds = new Set(mine.map((item) => item.contestId));
  return contests.map((contest) =>
    toPublicContest(
      contest,
      countById.get(contest.id) ?? 0,
      joinedIds.has(contest.id),
    ),
  );
}

async function getSeriesState(): Promise<{ confirmed: boolean; timeZone: string }> {
  const [setting] = await db
    .select({ value: hamsterAppSettings.value })
    .from(hamsterAppSettings)
    .where(eq(hamsterAppSettings.key, seriesSettingKey))
    .limit(1);
  const value =
    setting?.value && typeof setting.value === "object"
      ? (setting.value as { confirmed?: unknown; timeZone?: unknown })
      : {};
  return {
    confirmed: value.confirmed === true,
    timeZone:
      typeof value.timeZone === "string" ? value.timeZone : defaultTimeZone,
  };
}

async function readCalendar() {
  const entries = await db
    .select()
    .from(hamsterCalendarEntries)
    .orderBy(hamsterCalendarEntries.day);
  const series = await getSeriesState();
  return GetContestCalendarResponse.parse({
    timeZone: series.timeZone,
    seriesConfirmed: series.confirmed,
    entries: entries.map((entry) => ({
      ...entry,
      publishAt: entry.publishAt.toISOString(),
      endsAt: entry.endsAt.toISOString(),
      quizOptions: entry.quizOptions.length >= 2 ? entry.quizOptions : undefined,
    })),
  });
}

async function seedCalendar(): Promise<void> {
  const now = new Date();
  const today = dateOnlyInZone(now, defaultTimeZone);
  const rows = Array.from({ length: 30 }, (_, index) => {
    const date = calendarDateOffset(today, index);
    const publishAt = new Date(`${date}T17:00:00.000Z`);
    return {
      day: index + 1,
      date,
      title: `Конкурс дня ${index + 1}`,
      description: "Ежедневное состязание клуба Хомяка.",
      type: "random",
      conditions: "Вступи в конкурс до его окончания.",
      prize: "Награда клуба",
      winnersCount: 1,
      publishAt,
      endsAt: new Date(publishAt.getTime() + dayMs),
      timeZone: defaultTimeZone,
      imageUrl: null,
      status: "draft",
      quizOptions: [],
    };
  });
  await db
    .insert(hamsterCalendarEntries)
    .values(rows)
    .onConflictDoNothing({ target: hamsterCalendarEntries.day });
}

async function publicCalendarContests(telegramId: string) {
  const now = new Date();
  const rows = await db
    .select()
    .from(hamsterContests)
    .where(
      and(
        inArray(hamsterContests.status, ["open", "scheduled", "completed"]),
        gt(hamsterContests.endsAt, now),
      ),
    )
    .orderBy(hamsterContests.startsAt);
  return GetContestsResponse.parse(await withParticipation(rows, telegramId));
}

router.get("/contests", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }
  try {
    res.json(await publicCalendarContests(req.telegramUser.telegramId));
  } catch (error) {
    req.log.error({ err: error }, "Failed to load contests");
    res.status(500).json({ error: "Не удалось загрузить конкурсы" });
  }
});

router.post("/contests/:contestId/join", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }
  const params = JoinContestParams.safeParse(req.params);
  const body = JoinContestBody.safeParse(req.body ?? {});
  if (!params.success || !body.success || !isUuid(params.data.contestId)) {
    res.status(400).json({ error: "Некорректные данные конкурса" });
    return;
  }

  try {
    const [contest] = await db
      .select()
      .from(hamsterContests)
      .where(eq(hamsterContests.id, params.data.contestId))
      .limit(1);
    if (!contest || contest.status !== "open") {
      res.status(400).json({ error: "Регистрация в этот конкурс закрыта" });
      return;
    }
    if (contest.endsAt <= new Date()) {
      res.status(400).json({ error: "Конкурс уже завершён" });
      return;
    }
    if (contest.vipOnly) {
      const [player] = await db
        .select({ vipExpiresAt: hamsterPlayers.vipExpiresAt })
        .from(hamsterPlayers)
        .where(eq(hamsterPlayers.telegramId, req.telegramUser.telegramId))
        .limit(1);
      if (!player?.vipExpiresAt || player.vipExpiresAt <= new Date()) {
        res.status(403).json({ error: "Для участия нужен активный VIP" });
        return;
      }
    }
    if (contest.requiresSubscription) {
      const channelId = process.env.TELEGRAM_CHANNEL_ID;
      if (!channelId) {
        res.status(503).json({ error: "Проверка подписки Telegram не настроена" });
        return;
      }
      const member = await telegramCall<{ status: string; is_member?: boolean }>(
        "getChatMember",
        { chat_id: channelId, user_id: req.telegramUser.telegramId },
      );
      if (
        member.status === "left" ||
        member.status === "kicked" ||
        (member.status === "restricted" && !member.is_member)
      ) {
        res.status(403).json({ error: "Сначала подпишитесь на канал конкурса" });
        return;
      }
    }
    if (
      contest.type === "quiz" &&
      (body.data.selectedOption == null ||
        body.data.selectedOption !== contest.quizCorrectOption)
    ) {
      res.status(400).json({ error: "Ответ на вопрос неверный" });
      return;
    }

    const [entry] = await db
      .insert(hamsterContestEntries)
      .values({
        contestId: contest.id,
        telegramId: req.telegramUser.telegramId,
        selectedOption: body.data.selectedOption ?? null,
      })
      .onConflictDoNothing()
      .returning({ id: hamsterContestEntries.id });
    if (!entry) {
      res.status(409).json({ error: "Ты уже участвуешь в этом конкурсе" });
      return;
    }
    const response = await withParticipation([contest], req.telegramUser.telegramId);
    res.json(JoinContestResponse.parse(response[0]));
  } catch (error) {
    req.log.error({ err: error }, "Failed to join contest");
    res.status(500).json({ error: "Не удалось вступить в конкурс" });
  }
});

admin.get("/overview", async (req, res): Promise<void> => {
  try {
    const now = new Date();
    const [players, activeContests, scheduledPosts, pendingDraws, series, bot] =
      await Promise.all([
        db.select({ value: count() }).from(hamsterPlayers),
        db
          .select({ value: count() })
          .from(hamsterContests)
          .where(eq(hamsterContests.status, "open")),
        db
          .select({ value: count() })
          .from(hamsterContests)
          .where(eq(hamsterContests.status, "scheduled")),
        db
          .select({ value: count() })
          .from(hamsterContests)
          .where(
            and(
              eq(hamsterContests.status, "open"),
              lte(hamsterContests.endsAt, now),
            ),
          ),
        getSeriesState(),
        import("../lib/telegram")
          .then(({ getBot }) => getBot())
          .catch(() => null),
      ]);
    res.json(
      GetAdminOverviewResponse.parse({
        players: Number(players[0]?.value ?? 0),
        activeContests: Number(activeContests[0]?.value ?? 0),
        scheduledPosts: Number(scheduledPosts[0]?.value ?? 0),
        pendingDraws: Number(pendingDraws[0]?.value ?? 0),
        telegramReady: bot !== null,
        channelConfigured: Boolean(process.env.TELEGRAM_CHANNEL_ID),
        seriesConfirmed: series.confirmed,
        botUsername: bot?.username ?? null,
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Failed to load contest admin overview");
    res.status(500).json({ error: "Не удалось загрузить панель управления" });
  }
});

async function adminContestList() {
  const rows = await db
    .select()
    .from(hamsterContests)
    .orderBy(desc(hamsterContests.createdAt));
  if (rows.length === 0) return GetAdminContestsResponse.parse([]);
  const counts = await db
    .select({ contestId: hamsterContestEntries.contestId, total: count() })
    .from(hamsterContestEntries)
    .where(inArray(hamsterContestEntries.contestId, rows.map((row) => row.id)))
    .groupBy(hamsterContestEntries.contestId);
  const countById = new Map(counts.map((item) => [item.contestId, Number(item.total)]));
  return GetAdminContestsResponse.parse(
    rows.map((row) => toAdminContest(row, countById.get(row.id) ?? 0, false)),
  );
}

admin.get("/contests", async (req, res): Promise<void> => {
  try {
    res.json(await adminContestList());
  } catch (error) {
    req.log.error({ err: error }, "Failed to load admin contests");
    res.status(500).json({ error: "Не удалось загрузить конкурсы" });
  }
});

admin.post("/contests", async (req, res): Promise<void> => {
  const parsed = CreateContestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const input = parsed.data;
    const [contest] = await db
      .insert(hamsterContests)
      .values({
        title: input.title,
        description: input.description,
        type: input.type,
        prize: input.prize,
        winnersCount: input.winnersCount,
        startsAt: new Date(input.startsAt),
        endsAt: new Date(input.endsAt),
        timeZone: input.timeZone,
        conditions: input.conditions,
        vipOnly: input.vipOnly,
        requiresSubscription: input.requiresSubscription ?? false,
        quizQuestion: input.quizQuestion ?? null,
        quizOptions: input.quizOptions ?? [],
        quizCorrectOption: input.quizCorrectOption ?? null,
        imageUrl: input.imageUrl ?? null,
      })
      .returning();
    res.status(201).json(
      CreateContestResponse.parse(toAdminContest(contest, 0, false)),
    );
  } catch (error) {
    req.log.error({ err: error }, "Failed to create contest draft");
    res.status(500).json({ error: "Не удалось создать черновик конкурса" });
  }
});

admin.patch("/contests/:contestId", async (req, res): Promise<void> => {
  const params = UpdateContestParams.safeParse(req.params);
  const parsed = UpdateContestBody.safeParse(req.body);
  if (
    !params.success ||
    !parsed.success ||
    !isUuid(params.data.contestId) ||
    Object.keys(parsed.data).length === 0
  ) {
    res.status(400).json({ error: "Некорректные данные конкурса" });
    return;
  }
  try {
    const [existing] = await db
      .select()
      .from(hamsterContests)
      .where(eq(hamsterContests.id, params.data.contestId))
      .limit(1);
    if (!existing) {
      res.status(404).json({ error: "Конкурс не найден" });
      return;
    }
    if (existing.status !== "draft" && existing.status !== "scheduled") {
      res.status(400).json({ error: "Этот конкурс уже нельзя редактировать" });
      return;
    }
    const { startsAt, endsAt, ...fields } = parsed.data;
    const [updated] = await db
      .update(hamsterContests)
      .set({
        ...fields,
        ...(startsAt ? { startsAt: new Date(startsAt) } : {}),
        ...(endsAt ? { endsAt: new Date(endsAt) } : {}),
        updatedAt: new Date(),
      })
      .where(eq(hamsterContests.id, existing.id))
      .returning();
    const [countRow] = await db
      .select({ value: count() })
      .from(hamsterContestEntries)
      .where(eq(hamsterContestEntries.contestId, existing.id));
    res.json(
      UpdateContestResponse.parse(
        toAdminContest(updated, Number(countRow?.value ?? 0), false),
      ),
    );
  } catch (error) {
    req.log.error({ err: error }, "Failed to update contest");
    res.status(500).json({ error: "Не удалось сохранить конкурс" });
  }
});

async function publishContest(contest: typeof hamsterContests.$inferSelect) {
  if (publishing.has(contest.id)) throw new Error("Публикация уже выполняется");
  publishing.add(contest.id);
  try {
    const messageId = await sendContestPost({
      id: contest.id,
      title: contest.title,
      description: contest.description,
      prize: contest.prize,
      winnersCount: contest.winnersCount,
      conditions: contest.conditions,
      endsAt: contest.endsAt,
      imageUrl: contest.imageUrl,
    });
    const [updated] = await db
      .update(hamsterContests)
      .set({
        status: "open",
        telegramMessageId: String(messageId),
        lastError: null,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(hamsterContests.id, contest.id),
          inArray(hamsterContests.status, ["draft", "scheduled"]),
        ),
      )
      .returning();
    if (!updated) throw new Error("Статус конкурса уже изменился");
    await db
      .update(hamsterCalendarEntries)
      .set({ status: "published" })
      .where(eq(hamsterCalendarEntries.contestId, contest.id));
    retryAfter.delete(contest.id);
    return updated;
  } catch (error) {
    await db
      .update(hamsterContests)
      .set({ lastError: errorMessage(error), updatedAt: new Date() })
      .where(eq(hamsterContests.id, contest.id));
    throw error;
  } finally {
    publishing.delete(contest.id);
  }
}

async function drawWinners(contest: typeof hamsterContests.$inferSelect) {
  const entries = await db
    .select({
      telegramId: hamsterContestEntries.telegramId,
      selectedOption: hamsterContestEntries.selectedOption,
    })
    .from(hamsterContestEntries)
    .where(eq(hamsterContestEntries.contestId, contest.id));
  const eligible =
    contest.type === "quiz"
      ? entries.filter((entry) => entry.selectedOption === contest.quizCorrectOption)
      : entries;
  const playerIds = eligible.map((entry) => entry.telegramId);
  if (playerIds.length === 0) return [];

  let orderById = new Map<string, number>();
  if (contest.type === "taps" || contest.type === "achievements") {
    const players = await db
      .select({
        telegramId: hamsterPlayers.telegramId,
        score:
          contest.type === "taps"
            ? hamsterPlayers.totalTaps
            : hamsterPlayers.level,
      })
      .from(hamsterPlayers)
      .where(inArray(hamsterPlayers.telegramId, playerIds));
    orderById = new Map(players.map((player) => [player.telegramId, player.score]));
  } else if (contest.type === "referrals") {
    const referrals = await db
      .select({
        inviterId: hamsterReferrals.inviterId,
        total: count(),
      })
      .from(hamsterReferrals)
      .where(inArray(hamsterReferrals.inviterId, playerIds))
      .groupBy(hamsterReferrals.inviterId);
    orderById = new Map(
      referrals.map((referral) => [referral.inviterId, Number(referral.total)]),
    );
  }

  const ordered = [...eligible];
  if (contest.type === "random" || contest.type === "quiz") {
    for (let index = ordered.length - 1; index > 0; index -= 1) {
      const swap = randomInt(index + 1);
      [ordered[index], ordered[swap]] = [ordered[swap]!, ordered[index]!];
    }
  } else {
    ordered.sort(
      (left, right) =>
        (orderById.get(right.telegramId) ?? 0) -
        (orderById.get(left.telegramId) ?? 0),
    );
  }
  const winners = ordered.slice(0, contest.winnersCount);
  const players = await db
    .select({
      telegramId: hamsterPlayers.telegramId,
      firstName: hamsterPlayers.firstName,
      lastName: hamsterPlayers.lastName,
      username: hamsterPlayers.username,
    })
    .from(hamsterPlayers)
    .where(inArray(hamsterPlayers.telegramId, winners.map((winner) => winner.telegramId)));
  const playerById = new Map(players.map((player) => [player.telegramId, player]));
  return winners.map((winner) => {
    const player = playerById.get(winner.telegramId);
    if (!player) return "Игрок";
    return player.username
      ? `@${player.username}`
      : `${player.firstName}${player.lastName ? ` ${player.lastName}` : ""}`;
  });
}

admin.post("/contests/:contestId/actions", async (req, res): Promise<void> => {
  const params = RunContestActionParams.safeParse(req.params);
  const parsed = RunContestActionBody.safeParse(req.body);
  if (!params.success || !parsed.success || !isUuid(params.data.contestId)) {
    res.status(400).json({ error: "Некорректное действие конкурса" });
    return;
  }
  try {
    const [contest] = await db
      .select()
      .from(hamsterContests)
      .where(eq(hamsterContests.id, params.data.contestId))
      .limit(1);
    if (!contest) {
      res.status(404).json({ error: "Конкурс не найден" });
      return;
    }
    let updated = contest;
    if (parsed.data.action === "schedule") {
      const scheduledAt = new Date(parsed.data.scheduledAt ?? contest.startsAt);
      if (Number.isNaN(scheduledAt.getTime()) || scheduledAt <= new Date()) {
        res.status(400).json({ error: "Укажите дату публикации в будущем" });
        return;
      }
      const duration = contest.endsAt.getTime() - contest.startsAt.getTime();
      [updated] = await db
        .update(hamsterContests)
        .set({
          status: "scheduled",
          startsAt: scheduledAt,
          endsAt: new Date(scheduledAt.getTime() + Math.max(duration, dayMs)),
          lastError: null,
          updatedAt: new Date(),
        })
        .where(eq(hamsterContests.id, contest.id))
        .returning();
    } else if (parsed.data.action === "publish") {
      if (contest.status !== "draft" && contest.status !== "scheduled") {
        res.status(400).json({ error: "Этот конкурс нельзя опубликовать" });
        return;
      }
      updated = await publishContest(contest);
    } else if (parsed.data.action === "cancel") {
      if (contest.status === "completed" || contest.status === "cancelled") {
        res.status(400).json({ error: "Этот конкурс уже завершён" });
        return;
      }
      [updated] = await db
        .update(hamsterContests)
        .set({ status: "cancelled", updatedAt: new Date() })
        .where(eq(hamsterContests.id, contest.id))
        .returning();
      await db
        .update(hamsterCalendarEntries)
        .set({ status: "draft", contestId: null })
        .where(eq(hamsterCalendarEntries.contestId, contest.id));
    } else {
      if (contest.status !== "open") {
        res.status(400).json({ error: "Розыгрыш доступен только для открытого конкурса" });
        return;
      }
      const winners = await drawWinners(contest);
      await sendContestResults({ title: contest.title, winners });
      [updated] = await db
        .update(hamsterContests)
        .set({
          status: "completed",
          winners,
          drawnAt: new Date(),
          updatedAt: new Date(),
          lastError: null,
        })
        .where(eq(hamsterContests.id, contest.id))
        .returning();
    }
    const [countRow] = await db
      .select({ value: count() })
      .from(hamsterContestEntries)
      .where(eq(hamsterContestEntries.contestId, contest.id));
    res.json(
      RunContestActionResponse.parse(
        toAdminContest(updated, Number(countRow?.value ?? 0), false),
      ),
    );
  } catch (error) {
    req.log.error({ err: error }, "Failed to run contest action");
    res.status(400).json({ error: errorMessage(error) });
  }
});

admin.get("/calendar", async (req, res): Promise<void> => {
  try {
    await seedCalendar();
    res.json(await readCalendar());
  } catch (error) {
    req.log.error({ err: error }, "Failed to load contest calendar");
    res.status(500).json({ error: "Не удалось загрузить календарь конкурсов" });
  }
});

admin.put("/calendar/:day", async (req, res): Promise<void> => {
  const params = UpdateCalendarDayParams.safeParse(req.params);
  const parsed = UpdateCalendarDayBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "Некорректные данные календаря" });
    return;
  }
  try {
    await seedCalendar();
    const [existing] = await db
      .select()
      .from(hamsterCalendarEntries)
      .where(eq(hamsterCalendarEntries.day, params.data.day))
      .limit(1);
    if (!existing) {
      res.status(404).json({ error: "День календаря не найден" });
      return;
    }
    const input = parsed.data;
    const values = {
      title: input.title,
      description: input.description,
      type: input.type,
      conditions: input.conditions,
      prize: input.prize,
      winnersCount: input.winnersCount,
      publishAt: new Date(input.publishAt),
      endsAt: new Date(input.endsAt),
      timeZone: input.timeZone,
      imageUrl: input.imageUrl ?? null,
      requiresSubscription: input.requiresSubscription ?? false,
      quizQuestion: input.quizQuestion ?? null,
      quizOptions: input.quizOptions ?? [],
      quizCorrectOption: input.quizCorrectOption ?? null,
    };
    const [updated] = await db
      .update(hamsterCalendarEntries)
      .set(values)
      .where(eq(hamsterCalendarEntries.day, params.data.day))
      .returning();
    if (existing.contestId) {
      await db
        .update(hamsterContests)
        .set({
          title: values.title,
          description: values.description,
          type: values.type,
          conditions: values.conditions,
          prize: values.prize,
          winnersCount: values.winnersCount,
          startsAt: values.publishAt,
          endsAt: values.endsAt,
          timeZone: values.timeZone,
          imageUrl: values.imageUrl,
          requiresSubscription: values.requiresSubscription,
          quizQuestion: values.quizQuestion,
          quizOptions: values.quizOptions,
          quizCorrectOption: values.quizCorrectOption,
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(hamsterContests.id, existing.contestId),
            eq(hamsterContests.status, "scheduled"),
          ),
        );
    }
    res.json(
      UpdateCalendarDayResponse.parse({
        ...updated,
        publishAt: updated.publishAt.toISOString(),
        endsAt: updated.endsAt.toISOString(),
        quizOptions:
          updated.quizOptions.length >= 2 ? updated.quizOptions : undefined,
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Failed to update contest calendar day");
    res.status(500).json({ error: "Не удалось сохранить день календаря" });
  }
});

admin.post("/calendar/confirm", async (req, res): Promise<void> => {
  const parsed = ConfirmContestSeriesBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!process.env.TELEGRAM_CHANNEL_ID) {
    res.status(503).json({
      error: "Добавьте бота администратором канала и укажите TELEGRAM_CHANNEL_ID",
    });
    return;
  }
  try {
    await seedCalendar();
    const series = await getSeriesState();
    if (series.confirmed) {
      res.status(409).json({ error: "Серия уже подтверждена" });
      return;
    }
    const now = new Date();
    const entries = await db
      .select()
      .from(hamsterCalendarEntries)
      .where(eq(hamsterCalendarEntries.status, "draft"))
      .orderBy(hamsterCalendarEntries.day);
    await db.transaction(async (tx) => {
      for (const entry of entries) {
        if (entry.contestId) continue;
        const [contest] = await tx
          .insert(hamsterContests)
          .values({
            title: entry.title,
            description: entry.description,
            type: entry.type,
            status: "scheduled",
            prize: entry.prize,
            winnersCount: entry.winnersCount,
            startsAt: entry.publishAt,
            endsAt: entry.endsAt,
            timeZone: parsed.data.timeZone,
            conditions: entry.conditions,
            vipOnly: false,
            requiresSubscription: entry.requiresSubscription,
            quizQuestion: entry.quizQuestion,
            quizOptions: entry.quizOptions,
            quizCorrectOption: entry.quizCorrectOption,
            imageUrl: entry.imageUrl,
            createdAt: now,
            updatedAt: now,
          })
          .returning({ id: hamsterContests.id });
        await tx
          .update(hamsterCalendarEntries)
          .set({
            status: "scheduled",
            contestId: contest.id,
            timeZone: parsed.data.timeZone,
          })
          .where(eq(hamsterCalendarEntries.day, entry.day));
      }
      await tx
        .insert(hamsterAppSettings)
        .values({
          key: seriesSettingKey,
          value: { confirmed: true, timeZone: parsed.data.timeZone },
          updatedAt: now,
        })
        .onConflictDoUpdate({
          target: hamsterAppSettings.key,
          set: {
            value: { confirmed: true, timeZone: parsed.data.timeZone },
            updatedAt: now,
          },
        });
    });
    res.json(ConfirmContestSeriesResponse.parse(await readCalendar()));
    void dispatchScheduledContests();
  } catch (error) {
    req.log.error({ err: error }, "Failed to confirm contest series");
    res.status(500).json({ error: "Не удалось запустить серию конкурсов" });
  }
});

async function dispatchScheduledContests(): Promise<void> {
  if (!process.env.TELEGRAM_CHANNEL_ID) return;
  const now = new Date();
  const due = await db
    .select()
    .from(hamsterContests)
    .where(
      and(
        eq(hamsterContests.status, "scheduled"),
        lte(hamsterContests.startsAt, now),
        gt(hamsterContests.endsAt, now),
      ),
    );
  for (const contest of due) {
    if ((retryAfter.get(contest.id) ?? 0) > Date.now()) continue;
    try {
      await publishContest(contest);
    } catch (error) {
      retryAfter.set(contest.id, Date.now() + 5 * 60 * 1000);
      logger.warn({ err: error, contestId: contest.id }, "Scheduled contest post failed");
    }
  }
  await db
    .update(hamsterContests)
    .set({
      status: "cancelled",
      lastError: "Срок конкурса истёк до публикации",
      updatedAt: now,
    })
    .where(
      and(
        eq(hamsterContests.status, "scheduled"),
        lte(hamsterContests.endsAt, now),
      ),
    );
}

export function startContestScheduler(): void {
  const timer = setInterval(() => {
    void dispatchScheduledContests().catch((error: unknown) => {
      logger.error({ err: error }, "Contest scheduler failed");
    });
  }, 60_000);
  timer.unref();
  void dispatchScheduledContests().catch((error: unknown) => {
    logger.error({ err: error }, "Contest scheduler initial run failed");
  });
}

router.use("/admin", admin);

export default router;
