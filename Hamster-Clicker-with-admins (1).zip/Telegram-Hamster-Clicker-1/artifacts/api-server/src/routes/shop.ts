import { and, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  db,
  hamsterEquipped,
  hamsterInventory,
  hamsterPlayers,
} from "@workspace/db";
import {
  EquipCosmeticBody,
  EquipCosmeticResponse,
  GetShopResponse,
  PurchaseCosmeticBody,
  PurchaseCosmeticResponse,
} from "@workspace/api-zod";
import { requireTelegramAuth } from "../middlewares/telegram-auth";

type Category =
  | "clothing"
  | "color"
  | "glasses"
  | "hat"
  | "tap-effect"
  | "coin-animation"
  | "background"
  | "frame";

const catalog: Array<{
  id: string;
  name: string;
  category: Category;
  rarity: "common" | "rare" | "epic" | "legendary";
  description: string;
  price: number;
  vipOnly: boolean;
  color: string;
  icon: string;
}> = [
  { id: "suit-navy", name: "Синий деловой костюм", category: "clothing", rarity: "common", description: "Классика для первого совета директоров.", price: 600, vipOnly: false, color: "#4479c9", icon: "briefcase-business" },
  { id: "suit-gold", name: "Золотой костюм", category: "clothing", rarity: "legendary", description: "Эксклюзивный образ владельца империи.", price: 0, vipOnly: true, color: "#e7b64e", icon: "crown" },
  { id: "fur-caramel", name: "Карамельный мех", category: "color", rarity: "common", description: "Тёплый фирменный оттенок.", price: 450, vipOnly: false, color: "#ca8b4c", icon: "palette" },
  { id: "fur-violet", name: "Неоновая сирень", category: "color", rarity: "epic", description: "Сияние для ночных переговоров.", price: 0, vipOnly: true, color: "#a879f2", icon: "sparkles" },
  { id: "glasses-round", name: "Круглые очки", category: "glasses", rarity: "common", description: "Внимание к каждой цифре.", price: 700, vipOnly: false, color: "#80bdf9", icon: "glasses" },
  { id: "glasses-prism", name: "Призматические линзы", category: "glasses", rarity: "epic", description: "Фирменная VIP-оптика.", price: 0, vipOnly: true, color: "#c088ff", icon: "scan-eye" },
  { id: "hat-bowler", name: "Котелок", category: "hat", rarity: "rare", description: "Чуть больше статуса, чем вчера.", price: 1200, vipOnly: false, color: "#a7774d", icon: "hat" },
  { id: "hat-crown", name: "Корона инвестора", category: "hat", rarity: "legendary", description: "Только для VIP-клуба.", price: 0, vipOnly: true, color: "#f0c64c", icon: "crown" },
  { id: "tap-comet", name: "Кометный след", category: "tap-effect", rarity: "rare", description: "Золотой след за каждым тапом.", price: 1800, vipOnly: false, color: "#e8bb67", icon: "move-up-right" },
  { id: "tap-nebula", name: "Фиолетовая туманность", category: "tap-effect", rarity: "epic", description: "Премиальный эффект с неоновым шлейфом.", price: 0, vipOnly: true, color: "#a879f2", icon: "orbit" },
  { id: "coins-spark", name: "Искры монет", category: "coin-animation", rarity: "common", description: "Небольшой золотой всплеск дохода.", price: 900, vipOnly: false, color: "#efc95d", icon: "coins" },
  { id: "coins-stardust", name: "Звёздная пыль", category: "coin-animation", rarity: "epic", description: "Редкая анимация для VIP.", price: 0, vipOnly: true, color: "#d8b3ff", icon: "stars" },
  { id: "bg-boardroom", name: "Совет директоров", category: "background", rarity: "rare", description: "Панорамное окно и ночной город.", price: 2200, vipOnly: false, color: "#51628a", icon: "building-2" },
  { id: "bg-skyline", name: "Неоновый мегаполис", category: "background", rarity: "epic", description: "Премиальный горизонт большого города.", price: 0, vipOnly: true, color: "#764adb", icon: "city" },
  { id: "frame-platinum", name: "Платиновая рамка", category: "frame", rarity: "rare", description: "Сдержанный блеск в профиле.", price: 2500, vipOnly: false, color: "#bed1ec", icon: "badge" },
  { id: "frame-vip", name: "VIP-рамка", category: "frame", rarity: "legendary", description: "Знак закрытого клуба.", price: 0, vipOnly: true, color: "#e8bf61", icon: "shield-check" },
];

const router: IRouter = Router();
router.use(requireTelegramAuth);

async function getShop(telegramId: string) {
  const [player] = await db
    .select({ coins: hamsterPlayers.coins, vipExpiresAt: hamsterPlayers.vipExpiresAt })
    .from(hamsterPlayers)
    .where(eq(hamsterPlayers.telegramId, telegramId))
    .limit(1);
  if (!player) throw new Error("Player was not initialized");

  const [owned, equipped] = await Promise.all([
    db
      .select({ itemId: hamsterInventory.itemId })
      .from(hamsterInventory)
      .where(eq(hamsterInventory.telegramId, telegramId)),
    db
      .select({ itemId: hamsterEquipped.itemId })
      .from(hamsterEquipped)
      .where(eq(hamsterEquipped.telegramId, telegramId)),
  ]);
  const ownedIds = new Set(owned.map((row) => row.itemId));
  const equippedIds = new Set(equipped.map((row) => row.itemId));
  const vip = player.vipExpiresAt !== null && player.vipExpiresAt > new Date();

  return GetShopResponse.parse({
    balance: player.coins,
    items: catalog.map((item) => ({
      ...item,
      owned: ownedIds.has(item.id) || (item.vipOnly && vip),
      equipped: equippedIds.has(item.id),
    })),
  });
}

router.get("/shop", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }
  res.json(await getShop(req.telegramUser.telegramId));
});

router.post("/shop/purchase", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }
  const parsed = PurchaseCosmeticBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const item = catalog.find((entry) => entry.id === parsed.data.itemId);
  if (!item) {
    res.status(404).json({ error: "Предмет не найден" });
    return;
  }

  try {
    await db.transaction(async (tx) => {
      const [player] = await tx
        .select()
        .from(hamsterPlayers)
        .where(eq(hamsterPlayers.telegramId, req.telegramUser!.telegramId))
        .for("update")
        .limit(1);
      if (!player) throw new Error("Player was not initialized");
      const [owned] = await tx
        .select({ itemId: hamsterInventory.itemId })
        .from(hamsterInventory)
        .where(
          and(
            eq(hamsterInventory.telegramId, player.telegramId),
            eq(hamsterInventory.itemId, item.id),
          ),
        )
        .limit(1);
      if (owned) return;

      const vip = player.vipExpiresAt !== null && player.vipExpiresAt > new Date();
      if (item.vipOnly && !vip) throw new Error("Предмет доступен только VIP");
      if (player.coins < item.price) throw new Error("Недостаточно монет");

      await tx.insert(hamsterInventory).values({
        telegramId: player.telegramId,
        itemId: item.id,
      });
      await tx
        .update(hamsterPlayers)
        .set({ coins: player.coins - item.price })
        .where(eq(hamsterPlayers.telegramId, player.telegramId));
    });
    res.json(await getShop(req.telegramUser.telegramId));
  } catch (error) {
    res.status(400).json({
      error: error instanceof Error ? error.message : "Не удалось купить предмет",
    });
  }
});

router.post("/shop/equip", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }
  const parsed = EquipCosmeticBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const telegramId = req.telegramUser.telegramId;
  const itemId = parsed.data.itemId;
  if (itemId === null) {
    await db.delete(hamsterEquipped).where(eq(hamsterEquipped.telegramId, telegramId));
    res.json(await getShop(telegramId));
    return;
  }

  const item = catalog.find((entry) => entry.id === itemId);
  if (!item) {
    res.status(404).json({ error: "Предмет не найден" });
    return;
  }
  const [owned] = await db
    .select({ itemId: hamsterInventory.itemId })
    .from(hamsterInventory)
    .where(
      and(
        eq(hamsterInventory.telegramId, telegramId),
        eq(hamsterInventory.itemId, itemId),
      ),
    )
    .limit(1);
  const [player] = await db
    .select({ vipExpiresAt: hamsterPlayers.vipExpiresAt })
    .from(hamsterPlayers)
    .where(eq(hamsterPlayers.telegramId, telegramId))
    .limit(1);
  const activeVip = player?.vipExpiresAt !== null && player?.vipExpiresAt !== undefined && player.vipExpiresAt > new Date();
  if (!owned && !(item.vipOnly && activeVip)) {
    res.status(400).json({ error: "Сначала получите предмет в коллекцию" });
    return;
  }

  await db
    .insert(hamsterEquipped)
    .values({ telegramId, category: item.category, itemId })
    .onConflictDoUpdate({
      target: [hamsterEquipped.telegramId, hamsterEquipped.category],
      set: { itemId, equippedAt: new Date() },
    });
  res.json(await getShop(telegramId));
});

export default router;
