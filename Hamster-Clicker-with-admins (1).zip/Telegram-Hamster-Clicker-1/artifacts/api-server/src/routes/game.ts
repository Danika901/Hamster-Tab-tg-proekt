import { Router, type IRouter } from "express";
import {
  ClaimMissionParams,
  ClaimMissionResponse,
  PurchaseUpgradeBody,
  PurchaseUpgradeResponse,
  SubmitTapBody,
  SubmitTapResponse,
} from "@workspace/api-zod";
import { requireTelegramAuth } from "../middlewares/telegram-auth";
import {
  buyUpgrade,
  claimDailyMission,
  getPlayerState,
  registerTap,
} from "../lib/game";

const router: IRouter = Router();
router.use(requireTelegramAuth);

router.get("/game/state", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }
  res.json(
    await getPlayerState(req.telegramUser.telegramId, req.telegramAdmin === true),
  );
});

router.post("/game/taps", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }
  const parsed = SubmitTapBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const result = await registerTap(
      req.telegramUser.telegramId,
      parsed.data.requestId,
    );
    const state = await getPlayerState(
      req.telegramUser.telegramId,
      req.telegramAdmin === true,
    );
    res.json(SubmitTapResponse.parse({ coinsEarned: result.coinsEarned, state }));
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Тап не удалось обработать";
    const status = message.includes("энергии") || message.includes("быстрые")
      ? 409
      : 400;
    res.status(status).json({ error: message });
  }
});

router.post("/game/upgrades/purchase", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }
  const parsed = PurchaseUpgradeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    await buyUpgrade(req.telegramUser.telegramId, parsed.data.kind);
    res.json(
      PurchaseUpgradeResponse.parse(
        await getPlayerState(
          req.telegramUser.telegramId,
          req.telegramAdmin === true,
        ),
      ),
    );
  } catch (error) {
    res.status(400).json({
      error: error instanceof Error ? error.message : "Не удалось купить улучшение",
    });
  }
});

router.post("/missions/:missionId/claim", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }
  const parsed = ClaimMissionParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    await claimDailyMission(req.telegramUser.telegramId, parsed.data.missionId);
    res.json(
      ClaimMissionResponse.parse(
        await getPlayerState(
          req.telegramUser.telegramId,
          req.telegramAdmin === true,
        ),
      ),
    );
  } catch (error) {
    res.status(400).json({
      error: error instanceof Error ? error.message : "Не удалось получить награду",
    });
  }
});

export default router;
