import { eq, inArray } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  db,
  hamsterPlayers,
  hamsterReferrals,
} from "@workspace/db";
import { GetFriendsResponse } from "@workspace/api-zod";
import { requireTelegramAuth } from "../middlewares/telegram-auth";
import { getBot } from "../lib/telegram";

const router: IRouter = Router();
router.use(requireTelegramAuth);

router.get("/friends", async (req, res): Promise<void> => {
  if (!req.telegramUser) {
    res.status(401).json({ error: "Не удалось подтвердить аккаунт Telegram" });
    return;
  }

  const inviterId = req.telegramUser.telegramId;
  const [bot, referrals] = await Promise.all([
    getBot(),
    db
      .select()
      .from(hamsterReferrals)
      .where(eq(hamsterReferrals.inviterId, inviterId))
      .orderBy(hamsterReferrals.createdAt),
  ]);

  const inviteeIds = referrals.map((referral) => referral.inviteeId);
  const invitedPlayers =
    inviteeIds.length > 0
      ? await db
          .select()
          .from(hamsterPlayers)
          .where(inArray(hamsterPlayers.telegramId, inviteeIds))
      : [];
  const playerById = new Map(
    invitedPlayers.map((player) => [
      player.telegramId,
      `${player.firstName}${player.lastName ? ` ${player.lastName}` : ""}`,
    ]),
  );
  const earned = referrals.reduce(
    (sum, referral) =>
      sum +
      1000 +
      (referral.tapsRewardedAt ? 3000 : 0) +
      (referral.returnRewardedAt ? 5000 : 0),
    0,
  );

  res.json(
    GetFriendsResponse.parse({
      referralLink: bot?.username
        ? `https://t.me/${bot.username}?start=ref_${inviterId}`
        : "",
      invited: referrals.length,
      earned,
      milestones: [
        {
          id: "registration",
          title: "Приглашён зарегистрировался",
          reward: 1000,
          completed: referrals.length > 0,
          claimed: referrals.length > 0,
        },
        {
          id: "first-100-taps",
          title: "Приглашённый сделал первые 100 тапов",
          reward: 3000,
          completed: referrals.some((referral) => referral.tapsRewardedAt !== null),
          claimed: referrals.some((referral) => referral.tapsRewardedAt !== null),
        },
        {
          id: "next-day-return",
          title: "Приглашённый вернулся на следующий день",
          reward: 5000,
          completed: referrals.some((referral) => referral.returnRewardedAt !== null),
          claimed: referrals.some((referral) => referral.returnRewardedAt !== null),
        },
      ],
      referrals: referrals.map((referral) => ({
        displayName: playerById.get(referral.inviteeId) ?? "Игрок",
        joinedAt: referral.createdAt.toISOString(),
        taps: referral.tapsRewardedAt ? 100 : 0,
        rewards:
          1000 +
          (referral.tapsRewardedAt ? 3000 : 0) +
          (referral.returnRewardedAt ? 5000 : 0),
      })),
    }),
  );
});

export default router;
