import { timingSafeEqual } from "node:crypto";
import { and, asc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  db,
  hamsterPlayers,
  hamsterStarPayments,
} from "@workspace/db";
import {
  telegramCall,
  telegramWebhookSecret,
  type TelegramUpdate,
} from "../lib/telegram";
import { logger } from "../lib/logger";

const router: IRouter = Router();
const vipDurationMs = 30 * 24 * 60 * 60 * 1000;
const vipPayloadPattern = /^vip:30:(\d{1,32}):[0-9a-f-]{36}$/i;

function validPayload(payload: string, telegramId: string): boolean {
  const match = vipPayloadPattern.exec(payload);
  return Boolean(match && match[1] === telegramId);
}

function hasValidWebhookSecret(provided: string | undefined): boolean {
  const expected = telegramWebhookSecret();
  if (!expected || !provided) return false;
  const expectedBytes = Buffer.from(expected);
  const providedBytes = Buffer.from(provided);
  return (
    expectedBytes.length === providedBytes.length &&
    timingSafeEqual(expectedBytes, providedBytes)
  );
}

async function handlePreCheckout(
  update: NonNullable<TelegramUpdate["pre_checkout_query"]>,
): Promise<void> {
  const telegramId = String(update.from.id);
  const [player] = await db
    .select({ telegramId: hamsterPlayers.telegramId })
    .from(hamsterPlayers)
    .where(eq(hamsterPlayers.telegramId, telegramId))
    .limit(1);
  const approved =
    update.currency === "XTR" &&
    update.total_amount === 300 &&
    validPayload(update.invoice_payload, telegramId) &&
    Boolean(player);
  await telegramCall("answerPreCheckoutQuery", {
    pre_checkout_query_id: update.id,
    ok: approved,
    ...(!approved
      ? { error_message: "Счёт VIP недействителен. Создайте новый счёт в приложении." }
      : {}),
  });
}

async function recordSuccessfulPayment(
  update: NonNullable<TelegramUpdate["message"]>,
): Promise<void> {
  const payment = update.successful_payment;
  const telegramId = update.from ? String(update.from.id) : "";
  if (
    !payment ||
    payment.currency !== "XTR" ||
    payment.total_amount !== 300 ||
    !payment.telegram_payment_charge_id ||
    !validPayload(payment.invoice_payload, telegramId)
  ) {
    logger.warn({ updateId: update.message_id }, "Ignored invalid VIP payment update");
    return;
  }

  await db.transaction(async (tx) => {
    const [player] = await tx
      .select({ vipExpiresAt: hamsterPlayers.vipExpiresAt })
      .from(hamsterPlayers)
      .where(eq(hamsterPlayers.telegramId, telegramId))
      .for("update")
      .limit(1);
    if (!player) return;

    const [existing] = await tx
      .select({ id: hamsterStarPayments.id })
      .from(hamsterStarPayments)
      .where(eq(hamsterStarPayments.telegramChargeId, payment.telegram_payment_charge_id))
      .limit(1);
    if (existing) return;

    const now = new Date();
    const startsAt =
      player.vipExpiresAt && player.vipExpiresAt > now ? player.vipExpiresAt : now;
    const expiresAt = new Date(startsAt.getTime() + vipDurationMs);
    const [inserted] = await tx
      .insert(hamsterStarPayments)
      .values({
        telegramId,
        telegramChargeId: payment.telegram_payment_charge_id,
        providerChargeId: payment.provider_payment_charge_id ?? "",
        invoicePayload: payment.invoice_payload,
        amount: payment.total_amount,
        currency: payment.currency,
        vipDays: 30,
        startsAt,
        expiresAt,
      })
      .onConflictDoNothing({ target: hamsterStarPayments.telegramChargeId })
      .returning({ id: hamsterStarPayments.id });
    if (!inserted) return;

    await tx
      .update(hamsterPlayers)
      .set({ vipExpiresAt: expiresAt })
      .where(eq(hamsterPlayers.telegramId, telegramId));
  });
}

async function handleRefund(
  refund: NonNullable<TelegramUpdate["refunded_payment"]>,
): Promise<void> {
  if (refund.currency !== "XTR" || refund.total_amount !== 300) return;
  await db.transaction(async (tx) => {
    const [payment] = await tx
      .select({
        id: hamsterStarPayments.id,
        telegramId: hamsterStarPayments.telegramId,
      })
      .from(hamsterStarPayments)
      .where(
        and(
          eq(hamsterStarPayments.telegramChargeId, refund.telegram_payment_charge_id),
          eq(hamsterStarPayments.status, "paid"),
        ),
      )
      .limit(1);
    if (!payment) return;

    await tx
      .update(hamsterStarPayments)
      .set({ status: "refunded", refundedAt: new Date() })
      .where(eq(hamsterStarPayments.id, payment.id));

    await tx
      .select({ telegramId: hamsterPlayers.telegramId })
      .from(hamsterPlayers)
      .where(eq(hamsterPlayers.telegramId, payment.telegramId))
      .for("update")
      .limit(1);
    const now = new Date();
    const paidPayments = await tx
      .select()
      .from(hamsterStarPayments)
      .where(
        and(
          eq(hamsterStarPayments.telegramId, payment.telegramId),
          eq(hamsterStarPayments.status, "paid"),
        ),
      )
      .orderBy(asc(hamsterStarPayments.createdAt));

    let cursor = now;
    for (const paid of paidPayments) {
      if (paid.expiresAt <= now) continue;
      const duration =
        paid.startsAt < now
          ? paid.expiresAt.getTime() - now.getTime()
          : paid.vipDays * 24 * 60 * 60 * 1000;
      const startsAt = new Date(Math.max(cursor.getTime(), paid.startsAt.getTime()));
      const expiresAt = new Date(startsAt.getTime() + duration);
      await tx
        .update(hamsterStarPayments)
        .set({ startsAt, expiresAt })
        .where(eq(hamsterStarPayments.id, paid.id));
      cursor = expiresAt;
    }
    await tx
      .update(hamsterPlayers)
      .set({
        vipExpiresAt: cursor > now ? cursor : null,
      })
      .where(eq(hamsterPlayers.telegramId, payment.telegramId));
  });
}

router.post("/telegram/webhook", async (req, res): Promise<void> => {
  if (!hasValidWebhookSecret(req.header("x-telegram-bot-api-secret-token"))) {
    res.status(401).json({ error: "Недействительная подпись webhook" });
    return;
  }

  const update = req.body as TelegramUpdate | undefined;
  if (!update || typeof update !== "object") {
    res.status(400).json({ error: "Некорректное событие Telegram" });
    return;
  }

  try {
    if (update.pre_checkout_query) {
      await handlePreCheckout(update.pre_checkout_query);
    }
    if (update.message?.successful_payment) {
      await recordSuccessfulPayment(update.message);
    }
    const refund =
      update.message?.refunded_payment ?? update.refunded_payment;
    if (refund) await handleRefund(refund);
    res.sendStatus(200);
  } catch (error) {
    logger.error({ err: error, updateId: update.update_id }, "Telegram webhook failed");
    res.status(500).json({ error: "Не удалось обработать событие Telegram" });
  }
});

export default router;
