import app from "./app";
import { startContestScheduler } from "./routes/contests";
import { configureTelegramWebhook } from "./lib/telegram";
import { logger } from "./lib/logger";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  startContestScheduler();
  void configureTelegramWebhook().catch((error: unknown) => {
    logger.error({ err: error }, "Failed to configure Telegram webhook");
  });
});
