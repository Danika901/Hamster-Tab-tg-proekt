import { and, count, desc, eq, gt, isNull, sql } from "drizzle-orm";
import {
  db,
  hamsterInventory,
  hamsterMissionClaims,
  hamsterPlayers,
  hamsterReferrals,
  hamsterTaps,
} from "@workspace/db";
import { GetGameStateResponse } from "@workspace/api-zod";
import type { TelegramIdentity } from "../middlewares/telegram-auth";

const ENERGY_MAX = 1000;
const ENERGY_REGEN_MS = 3000;

export const dailyMissionDefinitions = [
  {
    id: "tap-50",
    title: "Разогрев",
    description: "Сделайте 50 тапов за день",
    target: 50,
    reward: 1000,
    premium: false,
  },
  {
    id: "tap-200",
    title: "Рабочая смена",
    description: "Сделайте 200 тапов за день",
    target: 200,
    reward: 2500,
    premium: false,
  },
  {
    id: "invite-one",
    title: "Новый партнёр",
    description: "Пригласите друга в игру",
    target: 1,
    reward: 1500,
    premium: false,
  },
  {
    id: "vip-tap-100",
    title: "Закрытый клуб",
    description: "Сделайте 100 тапов с активным VIP",
    target: 100,
    reward: 4000,
    premium: true,
  },
] as const;

const achievementDefinitions = [
  { id: "first-100", title: "Первый капитал", description: "Сделайте 100 тапов", target: 100, reward: 500 },
  { id: "tap-1000", title: "Деловая хватка", description: "Сделайте 1 000 тапов", target: 1000, reward: 2500 },
  { id: "level-5", title: "Молодой директор", description: "Достигните 5 уровня", target: 5, reward: 5000 },
  { id: "collector-5", title: "Коллекционер", description: "Соберите 5 предметов", target: 5, reward: 3000 },
] as const;

function utcDate(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function referralInviter(startParam: string | null): string | null {
  const match = startParam?.match(/^ref_(\d{1,32})$/);
  return match?.[1] ?? null;
}

export async function syncTelegramPlayer(identity: TelegramIdentity): Promise<void> {
  const now = new Date();
  const today = utcDate(now);

  await db.transaction(async (tx) => {
    let [player] = await tx
      .select()
      .from(hamsterPlayers)
      .where(eq(hamsterPlayers.telegramId, identity.telegramId))
      .for("update")
      .limit(1);

    if (!player) {
      [player] = await tx
        .insert(hamsterPlayers)
        .values({
          telegramId: identity.telegramId,
          username: identity.username,
          firstName: identity.firstName,
          lastName: identity.lastName,
          coins: 1000,
          energy: ENERGY_MAX,
          energyUpdatedAt: now,
          lastActiveAt: now,
          todayDate: today,
        })
        .onConflictDoNothing()
        .returning();
      if (!player) {
        [player] = await tx
          .select()
          .from(hamsterPlayers)
          .where(eq(hamsterPlayers.telegramId, identity.telegramId))
          .for("update")
          .limit(1);
      } else {
        const inviterId = referralInviter(identity.startParam);
        if (inviterId && inviterId !== identity.telegramId) {
          const inviter = await tx
            .select({ telegramId: hamsterPlayers.telegramId })
            .from(hamsterPlayers)
            .where(eq(hamsterPlayers.telegramId, inviterId))
            .limit(1);
          if (inviter.length > 0) {
            const [referral] = await tx
              .insert(hamsterReferrals)
              .values({
                inviterId,
                inviteeId: identity.telegramId,
                registrationRewardedAt: now,
                createdAt: now,
              })
              .onConflictDoNothing()
              .returning();
            if (referral) {
              await tx
                .update(hamsterPlayers)
                .set({
                  coins: sql`${hamsterPlayers.coins} + 1000`,
                  totalCoinsEarned: sql`${hamsterPlayers.totalCoinsEarned} + 1000`,
                })
                .where(eq(hamsterPlayers.telegramId, inviterId));
            }
          }
        }
      }
    }

    if (!player) throw new Error("Could not initialize Telegram player");

    const lastActive = player.lastActiveAt;
    const elapsedMs = Math.min(
      12 * 60 * 60 * 1000,
      Math.max(0, now.getTime() - lastActive.getTime()),
    );
    const accrued = elapsedMs * player.passiveIncome + player.passiveRemainder;
    const passiveCoins = Math.floor(accrued / 3_600_000);
    const passiveRemainder = accrued % 3_600_000;
    const elapsedEnergyMs = Math.max(
      0,
      now.getTime() - player.energyUpdatedAt.getTime(),
    );
    const recoveredEnergy = Math.min(
      ENERGY_MAX - player.energy,
      Math.floor(elapsedEnergyMs / ENERGY_REGEN_MS),
    );
    const energy = Math.min(ENERGY_MAX, player.energy + recoveredEnergy);
    const energyUpdatedAt =
      energy === ENERGY_MAX
        ? now
        : new Date(
            player.energyUpdatedAt.getTime() +
              recoveredEnergy * ENERGY_REGEN_MS,
          );
    const isNewDay = player.todayDate !== today;

    await tx
      .update(hamsterPlayers)
      .set({
        username: identity.username,
        firstName: identity.firstName,
        lastName: identity.lastName,
        energy,
        energyUpdatedAt,
        coins: player.coins + passiveCoins,
        totalCoinsEarned: player.totalCoinsEarned + passiveCoins,
        passiveRemainder,
        todayTaps: isNewDay ? 0 : player.todayTaps,
        todayDate: today,
        lastActiveAt: now,
      })
      .where(eq(hamsterPlayers.telegramId, identity.telegramId));

    if (lastActive.toISOString().slice(0, 10) < today) {
      const [referral] = await tx
        .update(hamsterReferrals)
        .set({ returnRewardedAt: now })
        .where(
          and(
            eq(hamsterReferrals.inviteeId, identity.telegramId),
            isNull(hamsterReferrals.returnRewardedAt),
          ),
        )
        .returning();
      if (referral) {
        await tx
          .update(hamsterPlayers)
          .set({
            coins: sql`${hamsterPlayers.coins} + 5000`,
            totalCoinsEarned: sql`${hamsterPlayers.totalCoinsEarned} + 5000`,
          })
          .where(eq(hamsterPlayers.telegramId, referral.inviterId));
      }
    }
  });
}

export async function getPlayerState(
  telegramId: string,
  isAdmin: boolean,
): Promise<ReturnType<typeof GetGameStateResponse.parse>> {
  const [player] = await db
    .select()
    .from(hamsterPlayers)
    .where(eq(hamsterPlayers.telegramId, telegramId))
    .limit(1);
  if (!player) throw new Error("Player was not initialized");

  const today = utcDate(new Date());
  const [claimedRows, referralCountRow, inventoryCountRow, rankRow] =
    await Promise.all([
      db
        .select({ missionId: hamsterMissionClaims.missionId })
        .from(hamsterMissionClaims)
        .where(
          and(
            eq(hamsterMissionClaims.telegramId, telegramId),
            eq(hamsterMissionClaims.claimDate, today),
          ),
        ),
      db
        .select({ value: count() })
        .from(hamsterReferrals)
        .where(eq(hamsterReferrals.inviterId, telegramId)),
      db
        .select({ value: count() })
        .from(hamsterInventory)
        .where(eq(hamsterInventory.telegramId, telegramId)),
      db
        .select({ value: count() })
        .from(hamsterPlayers)
        .where(gt(hamsterPlayers.coins, player.coins)),
    ]);
  const claims = new Set(claimedRows.map((row) => row.missionId));
  const referralCount = Number(referralCountRow[0]?.value ?? 0);
  const inventoryCount = Number(inventoryCountRow[0]?.value ?? 0);
  const rank = Number(rankRow[0]?.value ?? 0) + 1;
  const vipActive =
    player.vipExpiresAt !== null && player.vipExpiresAt.getTime() > Date.now();
  const energyRestoredAt =
    player.energy >= ENERGY_MAX
      ? new Date()
      : new Date(
          player.energyUpdatedAt.getTime() +
            (ENERGY_MAX - player.energy) * ENERGY_REGEN_MS,
        );

  const missions = dailyMissionDefinitions
    .filter((mission) => !mission.premium || vipActive)
    .map((mission) => {
      const progress =
        mission.id === "tap-50" || mission.id === "tap-200"
          ? player.todayTaps
          : mission.id === "invite-one"
            ? referralCount
            : player.todayTaps;
      return {
        id: mission.id,
        title: mission.title,
        description: mission.description,
        progress: Math.min(mission.target, progress),
        target: mission.target,
        reward: mission.reward,
        completed: progress >= mission.target,
        claimed: claims.has(mission.id),
        premium: mission.premium,
      };
    });

  const achievements = achievementDefinitions.map((achievement) => {
    const progress =
      achievement.id === "level-5"
        ? player.level
        : achievement.id === "collector-5"
          ? inventoryCount
          : player.totalTaps;
    return {
      id: achievement.id,
      title: achievement.title,
      description: achievement.description,
      progress: Math.min(achievement.target, progress),
      target: achievement.target,
      reward: achievement.reward,
      unlocked: progress >= achievement.target,
    };
  });

  const nextUpgradeCost = Math.max(100, (player.tapPower + 1) ** 2 * 100);
  return GetGameStateResponse.parse({
    player: {
      telegramId: player.telegramId,
      username: player.username,
      displayName: `${player.firstName}${player.lastName ? ` ${player.lastName}` : ""}`,
      isAdmin,
    },
    balance: player.coins,
    energy: {
      current: player.energy,
      maximum: ENERGY_MAX,
      restoredAt: energyRestoredAt.toISOString(),
    },
    level: player.level,
    experience: player.experience,
    power: player.tapPower,
    passiveIncome: player.passiveIncome,
    nextUpgradeCost,
    stats: {
      totalTaps: player.totalTaps,
      todayTaps: player.todayTaps,
      coinsEarned: player.totalCoinsEarned,
      rank,
    },
    missions,
    achievements,
    vip: {
      active: vipActive,
      durationDays: 30,
      priceStars: 300,
      expiresAt: player.vipExpiresAt?.toISOString() ?? null,
    },
  });
}

export async function registerTap(
  telegramId: string,
  requestId: string,
): Promise<{ coinsEarned: number }> {
  return db.transaction(async (tx) => {
    const [duplicate] = await tx
      .select({ coinsEarned: hamsterTaps.coinsEarned })
      .from(hamsterTaps)
      .where(
        and(
          eq(hamsterTaps.telegramId, telegramId),
          eq(hamsterTaps.requestId, requestId),
        ),
      )
      .limit(1);
    if (duplicate) return { coinsEarned: duplicate.coinsEarned };

    const [player] = await tx
      .select()
      .from(hamsterPlayers)
      .where(eq(hamsterPlayers.telegramId, telegramId))
      .for("update")
      .limit(1);
    if (!player) throw new Error("Player was not initialized");

    const now = new Date();
    if (player.energy < 1) throw new Error("Недостаточно энергии");
    if (
      player.lastTapAt &&
      now.getTime() - player.lastTapAt.getTime() < 65
    ) {
      throw new Error("Слишком быстрые тапы");
    }

    const coinsEarned = player.tapPower;
    const nextExperience = player.experience + 1;
    let level = player.level;
    let experience = nextExperience;
    while (experience >= level * 100) {
      experience -= level * 100;
      level += 1;
    }
    const today = utcDate(now);
    await tx.insert(hamsterTaps).values({
      telegramId,
      requestId,
      coinsEarned,
      createdAt: now,
    });
    await tx
      .update(hamsterPlayers)
      .set({
        coins: player.coins + coinsEarned,
        totalCoinsEarned: player.totalCoinsEarned + coinsEarned,
        energy: player.energy - 1,
        energyUpdatedAt: player.energyUpdatedAt,
        lastTapAt: now,
        lastActiveAt: now,
        totalTaps: player.totalTaps + 1,
        todayTaps: player.todayDate === today ? player.todayTaps + 1 : 1,
        todayDate: today,
        experience,
        level,
      })
      .where(eq(hamsterPlayers.telegramId, telegramId));

    if (player.totalTaps + 1 >= 100) {
      const [referral] = await tx
        .update(hamsterReferrals)
        .set({ tapsRewardedAt: now })
        .where(
          and(
            eq(hamsterReferrals.inviteeId, telegramId),
            isNull(hamsterReferrals.tapsRewardedAt),
          ),
        )
        .returning({ inviterId: hamsterReferrals.inviterId });
      if (referral) {
        const [inviter] = await tx
          .select({
            coins: hamsterPlayers.coins,
            earned: hamsterPlayers.totalCoinsEarned,
          })
          .from(hamsterPlayers)
          .where(eq(hamsterPlayers.telegramId, referral.inviterId))
          .limit(1);
        if (inviter) {
          await tx
            .update(hamsterPlayers)
            .set({
              coins: inviter.coins + 3000,
              totalCoinsEarned: inviter.earned + 3000,
            })
            .where(eq(hamsterPlayers.telegramId, referral.inviterId));
        }
      }
    }

    return { coinsEarned };
  });
}

export async function buyUpgrade(
  telegramId: string,
  kind: "tap-power" | "passive-income",
): Promise<void> {
  await db.transaction(async (tx) => {
    const [player] = await tx
      .select()
      .from(hamsterPlayers)
      .where(eq(hamsterPlayers.telegramId, telegramId))
      .for("update")
      .limit(1);
    if (!player) throw new Error("Player was not initialized");

    const cost =
      kind === "tap-power"
        ? Math.max(100, (player.tapPower + 1) ** 2 * 100)
        : Math.max(500, (player.passiveIncome + 1) * 1000);
    if (player.coins < cost) throw new Error("Недостаточно монет");

    await tx
      .update(hamsterPlayers)
      .set({
        coins: player.coins - cost,
        ...(kind === "tap-power"
          ? { tapPower: player.tapPower + 1 }
          : { passiveIncome: player.passiveIncome + 1 }),
        experience: player.experience + 25,
      })
      .where(eq(hamsterPlayers.telegramId, telegramId));
  });
}

export async function claimDailyMission(
  telegramId: string,
  missionId: string,
): Promise<void> {
  const mission = dailyMissionDefinitions.find((item) => item.id === missionId);
  if (!mission) throw new Error("Задание не найдено");
  const today = utcDate(new Date());

  await db.transaction(async (tx) => {
    const [player] = await tx
      .select()
      .from(hamsterPlayers)
      .where(eq(hamsterPlayers.telegramId, telegramId))
      .for("update")
      .limit(1);
    if (!player) throw new Error("Player was not initialized");
    const vipActive =
      player.vipExpiresAt !== null && player.vipExpiresAt.getTime() > Date.now();
    if (mission.premium && !vipActive) throw new Error("Требуется VIP");

    let progress = player.todayTaps;
    if (mission.id === "invite-one") {
      const [referrals] = await tx
        .select({ value: count() })
        .from(hamsterReferrals)
        .where(eq(hamsterReferrals.inviterId, telegramId));
      progress = Number(referrals?.value ?? 0);
    }
    if (progress < mission.target) throw new Error("Задание ещё не выполнено");

    const [claim] = await tx
      .insert(hamsterMissionClaims)
      .values({
        telegramId,
        missionId,
        claimDate: today,
        reward: mission.reward,
      })
      .onConflictDoNothing()
      .returning({ id: hamsterMissionClaims.id });
    if (!claim) throw new Error("Награда уже получена");

    await tx
      .update(hamsterPlayers)
      .set({
        coins: player.coins + mission.reward,
        totalCoinsEarned: player.totalCoinsEarned + mission.reward,
      })
      .where(eq(hamsterPlayers.telegramId, telegramId));
  });
}

export async function getLeaderboardRank(coins: number): Promise<number> {
  const [result] = await db
    .select({ value: count() })
    .from(hamsterPlayers)
    .where(gt(hamsterPlayers.coins, coins));
  return Number(result?.value ?? 0) + 1;
}

export async function getTopPlayers(limit = 20) {
  return db
    .select({
      telegramId: hamsterPlayers.telegramId,
      username: hamsterPlayers.username,
      firstName: hamsterPlayers.firstName,
      coins: hamsterPlayers.coins,
    })
    .from(hamsterPlayers)
    .orderBy(desc(hamsterPlayers.coins))
    .limit(limit);
}
