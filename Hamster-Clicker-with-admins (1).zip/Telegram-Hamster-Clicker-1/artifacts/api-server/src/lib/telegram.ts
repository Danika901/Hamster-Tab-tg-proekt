import { createHmac, randomUUID } from "node:crypto";

type TelegramEnvelope<T> = {
  ok: boolean;
  result?: T;
  description?: string;
};

export type TelegramBot = {
  id: number;
  is_bot: boolean;
  first_name: string;
  username?: string;
};

export type TelegramUpdate = {
  update_id: number;
  message?: {
    message_id: number;
    chat: { id: number; type: string };
    from?: {
      id: number;
      is_bot: boolean;
      first_name: string;
      last_name?: string;
      username?: string;
    };
    text?: string;
    successful_payment?: {
      currency: string;
      total_amount: number;
      invoice_payload: string;
      telegram_payment_charge_id: string;
      provider_payment_charge_id: string;
    };
    refunded_payment?: {
      currency: string;
      total_amount: number;
      invoice_payload: string;
      telegram_payment_charge_id: string;
      provider_payment_charge_id: string;
    };
  };
  pre_checkout_query?: {
    id: string;
    from: { id: number };
    currency: string;
    total_amount: number;
    invoice_payload: string;
  };
  refunded_payment?: {
    currency: string;
    total_amount: number;
    invoice_payload: string;
    telegram_payment_charge_id: string;
    provider_payment_charge_id: string;
  };
};

export async function telegramCall<T>(
  method: string,
  payload: Record<string, unknown>,
): Promise<T> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) throw new Error("TELEGRAM_BOT_TOKEN is not configured");

  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload),
  });
  const body = (await response.json()) as TelegramEnvelope<T>;
  if (!response.ok || !body.ok || body.result === undefined) {
    throw new Error(
      `Telegram ${method} failed: ${body.description ?? response.statusText}`,
    );
  }
  return body.result;
}

export function telegramWebhookSecret(): string | null {
  const sessionSecret = process.env.SESSION_SECRET;
  if (!sessionSecret) return null;
  return createHmac("sha256", sessionSecret)
    .update("hamster-clicker:telegram-webhook:v1")
    .digest("hex");
}

export async function configureTelegramWebhook(): Promise<void> {
  if (
    process.env.NODE_ENV !== "production" ||
    !process.env.REPLIT_DOMAINS ||
    !process.env.TELEGRAM_BOT_TOKEN
  ) {
    return;
  }

  const secret = telegramWebhookSecret();
  const domain = process.env.REPLIT_DOMAINS.split(",")[0]?.trim();
  if (!secret || !domain) return;

  const url = `https://${domain}/api/telegram/webhook`;
  await telegramCall<boolean>("setWebhook", {
    url,
    secret_token: secret,
    allowed_updates: ["message", "pre_checkout_query"],
    drop_pending_updates: false,
  });
}

export async function getBot(): Promise<TelegramBot | null> {
  if (!process.env.TELEGRAM_BOT_TOKEN) return null;
  return telegramCall<TelegramBot>("getMe", {});
}

export async function sendContestPost(
  contest: {
    id: string;
    title: string;
    description: string;
    prize: string;
    winnersCount: number;
    conditions: string;
    endsAt: Date;
    imageUrl: string | null;
  },
): Promise<number> {
  const channelId = process.env.TELEGRAM_CHANNEL_ID;
  if (!channelId) throw new Error("TELEGRAM_CHANNEL_ID is not configured");
  const bot = await getBot();
  if (!bot?.username) throw new Error("The Telegram bot has no public username");

  const text = [
    contest.title,
    "",
    contest.description,
    "",
    `Приз: ${contest.prize}`,
    `Победителей: ${contest.winnersCount}`,
    contest.conditions ? `Условия: ${contest.conditions}` : "",
    `Завершение: ${contest.endsAt.toLocaleString("ru-RU", { timeZone: "Europe/Warsaw" })}`,
  ]
    .filter(Boolean)
    .join("\n");
  const replyMarkup = {
    inline_keyboard: [
      [
        {
          text: "Участвовать в Mini App",
          url: `https://t.me/${bot.username}?start=contest_${contest.id}`,
        },
      ],
    ],
  };
  const result = contest.imageUrl
    ? await telegramCall<{ message_id: number }>("sendPhoto", {
        chat_id: channelId,
        photo: contest.imageUrl,
        caption: text.slice(0, 1024),
        reply_markup: replyMarkup,
      })
    : await telegramCall<{ message_id: number }>("sendMessage", {
        chat_id: channelId,
        text,
        reply_markup: replyMarkup,
        disable_web_page_preview: true,
      });
  return result.message_id;
}

export async function sendContestResults(
  contest: { title: string; winners: string[] },
): Promise<void> {
  const channelId = process.env.TELEGRAM_CHANNEL_ID;
  if (!channelId) throw new Error("TELEGRAM_CHANNEL_ID is not configured");
  const resultLines =
    contest.winners.length > 0
      ? contest.winners.map((winner, index) => `${index + 1}. ${winner}`)
      : ["Победителей нет: заявок не было."];
  await telegramCall("sendMessage", {
    chat_id: channelId,
    text: [`Итоги конкурса «${contest.title}»`, "", ...resultLines].join("\n"),
    disable_web_page_preview: true,
  });
}

export async function createVipInvoice(
  telegramId: string,
): Promise<{ invoiceUrl: string; payload: string }> {
  const payload = `vip:30:${telegramId}:${randomUUID()}`;
  const invoiceUrl = await telegramCall<string>("createInvoiceLink", {
    title: "VIP на 30 дней",
    description:
      "Доступ к VIP-косметике, премиальным фонам и заданиям на 30 дней. Действие начинается после подтверждённой оплаты.",
    payload,
    provider_token: "",
    currency: "XTR",
    prices: [{ label: "VIP на 30 дней", amount: 300 }],
  });
  return { invoiceUrl, payload };
}
