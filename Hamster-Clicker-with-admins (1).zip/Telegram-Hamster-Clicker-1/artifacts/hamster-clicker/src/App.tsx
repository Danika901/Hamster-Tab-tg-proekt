import { type ReactNode, type MouseEvent, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter, Link } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';
import { useHealthCheck, useGetGameState, useSubmitTap, usePurchaseUpgrade, useGetShop, usePurchaseCosmetic, useEquipCosmetic, useClaimMission, useGetFriends, useGetContests, useJoinContest, useCreateVipInvoice, useGetAdminOverview, useGetAdminContests, useCreateContest, useUpdateContest, useRunContestAction, useGetContestCalendar, useUpdateCalendarDay, useConfirmContestSeries, getGetGameStateQueryKey, getGetShopQueryKey, getGetFriendsQueryKey, getGetContestsQueryKey, getGetAdminOverviewQueryKey, getGetAdminContestsQueryKey, getGetContestCalendarQueryKey } from '@workspace/api-client-react';
import type { Contest, ContestInput, CalendarEntry, CalendarEntryUpdate } from '@workspace/api-client-react';
import { Activity, Award, Battery, CalendarDays, Check, CircleHelp, Coins, Crown, LoaderCircle, LockKeyhole, Medal, RefreshCw, Send, ShieldCheck, Shirt, ShoppingBag, Sparkles, Star, Swords, Users, Zap } from 'lucide-react';

const queryClient = new QueryClient();

const number = (n?: number) => new Intl.NumberFormat('ru-RU').format(n ?? 0);
const dates = (s: string) => { const d = new Date(s); return Number.isNaN(d.getTime()) ? s : d.toLocaleString('ru-RU',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}); };
const contestTypes: Record<string,string> = {random:'Случайный розыгрыш',taps:'Больше тапов',referrals:'Пригласи друзей',achievements:'Достижения',quiz:'Викторина',weekly:'Еженедельный',monthly:'Ежемесячный'};
function Button({children,onClick,disabled,className='',testId}:{children:ReactNode;onClick?:()=>void;disabled?:boolean;className?:string;testId?:string}) { return <button data-testid={testId} disabled={disabled} onClick={onClick} className={`rounded-xl px-4 py-2.5 font-semibold text-sm ${className||'btn-primary'}`}>{children}</button>; }
function Loading({label='Загружаем данные'}:{label?:string}) { return <div className="space-y-4">{[1,2,3].map(i=><div key={i} className="skeleton h-24 rounded-2xl"/>) }<p className="text-center text-xs text-muted-foreground">{label}</p></div>; }
function ErrorState({retry}:{retry:()=>void}) { return <div className="glass rounded-2xl p-8 text-center"><CircleHelp className="mx-auto mb-3 text-amber-300"/><h3 className="font-semibold">Не удалось загрузить данные</h3><p className="mt-1 text-sm text-muted-foreground">Проверьте соединение и попробуйте ещё раз.</p><Button onClick={retry} className="mt-5 inline-flex items-center gap-2"><RefreshCw size={15}/> Повторить</Button></div>; }
function SectionTitle({eyebrow,title,desc}:{eyebrow:string;title:string;desc:string}) { return <div className="mb-7"><p className="mb-2 text-[11px] font-bold uppercase tracking-[.2em] text-violet-300">{eyebrow}</p><h1 className="brand text-3xl font-bold">{title}</h1><p className="mt-2 text-sm text-muted-foreground">{desc}</p></div>; }

const navItems=[['/','Игра',Coins],['/profile','Профиль',Medal],['/shop','Гардероб',Shirt],['/friends','Друзья',Users],['/contests','Конкурсы',Swords],['/vip','Клуб VIP',Crown],['/settings','Настройки',ShieldCheck]] as const;
function Shell({children}:{children:ReactNode}) {
 const [path]=useLocation(); const health=useHealthCheck();
 return <div className="app-shell">
  <aside className="side-nav"><Link href="/" className="mb-10 flex items-center gap-3 px-2 text-inherit no-underline"><div className="grid h-10 w-10 place-items-center rounded-xl bg-violet-500/20 text-violet-300"><Coins size={21}/></div><div><div className="brand text-lg font-bold">HAMSTER</div><div className="text-[10px] tracking-[.18em] text-muted-foreground">CAPITAL CLUB</div></div></Link><div className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[.2em] text-muted-foreground">Мой кабинет</div><nav className="space-y-1">{navItems.map(([href,label,Icon])=><Link key={href} href={href} className={`nav-link flex items-center gap-3 rounded-xl px-3 py-3 text-sm no-underline ${path===href?'active':''}`}><Icon size={18}/>{label}</Link>)}</nav>{health.isError&&<div className="mt-6 rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 text-xs text-amber-200">Сервер игры сейчас недоступен</div>}</aside>
  <main className="main-content"><header className="topbar mb-8 items-center justify-between"><div><p className="text-xs text-muted-foreground">Твой путь к вершине</p><div className="brand text-lg font-semibold">Капитал начинается с одного тапа</div></div><div className="flex items-center gap-2 rounded-full border border-violet-400/20 bg-violet-400/5 px-3 py-2 text-xs text-violet-200"><span className="h-2 w-2 rounded-full bg-emerald-400"/>{health.isError?'Нет связи':'Система активна'}</div></header>{children}</main>
  <nav className="mobile-nav">{navItems.map(([href,label,Icon])=><Link key={href} href={href} aria-label={label} className={`nav-link flex min-w-0 flex-1 flex-col items-center gap-1 rounded-xl px-0 py-1.5 text-[9px] no-underline ${path===href?'active':''}`}><Icon size={19}/><span className="whitespace-nowrap">{label}</span></Link>)}</nav>
 </div>;
}

function Home() {
 const q=useGetGameState(); const qc=useQueryClient(); const tap=useSubmitTap(); const upgrade=usePurchaseUpgrade(); const claim=useClaimMission(); const [feedback,setFeedback]=useState<{id:number;x:number;y:number}[]>([]);
 const refresh=()=>qc.invalidateQueries({queryKey:getGetGameStateQueryKey()}); const s=q.data;
 const doTap=(e:MouseEvent<HTMLButtonElement>)=>{const rect=e.currentTarget.getBoundingClientRect();const id=Date.now();setFeedback(v=>[...v,{id,x:e.clientX-rect.left,y:e.clientY-rect.top}]);window.setTimeout(()=>setFeedback(v=>v.filter(x=>x.id!==id)),900);tap.mutate({data:{requestId:typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():`tap-${Date.now()}-${Math.random().toString(36).slice(2)}`}},{onSuccess:r=>{qc.setQueryData(getGetGameStateQueryKey(),r.state);qc.invalidateQueries({queryKey:getGetShopQueryKey()})}});};
 return <Shell>{q.isLoading?<Loading label="Считаем твой капитал"/>:q.isError||!s?<ErrorState retry={refresh}/>:<div className="appear">
  <div className="mb-5 flex items-start justify-between gap-3"><div><p className="text-xs text-violet-200">Добро пожаловать в игру, {s.player.displayName}</p><h1 className="hero-title brand mt-1 text-3xl font-bold">Империя растёт</h1></div><div className="flex items-center gap-2 rounded-full border border-amber-300/20 bg-amber-300/5 px-3 py-2 text-xs text-amber-200"><Crown size={15}/>{s.vip.active?'VIP до '+dates(s.vip.expiresAt||''):'Уровень '+s.level}</div></div>
  <div className="game-stats mb-5 grid grid-cols-2 gap-3"><Metric label="Баланс" value={number(s.balance)} icon={<Coins size={17}/>} highlight/><Metric label="Энергия" value={`${number(s.energy.current)} / ${number(s.energy.maximum)}`} icon={<Battery size={17}/>} detail="восстанавливается автоматически"/><Metric label="Сила тапа" value={`+${number(s.power)}`} icon={<Zap size={17}/>}/><Metric label="Пассивный доход" value={`${number(s.passiveIncome)} / ч`} icon={<Activity size={17}/>}/></div>
  <div className="game-layout grid gap-5">
   <section className="glass wood-panel relative overflow-hidden rounded-[28px] p-5 sm:p-7"><div className="absolute left-5 top-5 z-10"><span className="rounded-full border border-violet-300/20 bg-black/20 px-3 py-1 text-xs text-violet-200">Директор • Ур. {s.level}</span><h2 className="brand mt-3 text-2xl font-bold">Борис Хомяков</h2><p className="text-xs text-muted-foreground">Председатель совета тапов</p></div><div className="mascot-stage flex min-h-[330px] items-end justify-center pt-20"><button data-testid="button-tap-hamster" aria-label="Нажать на хомяка и заработать монеты" disabled={tap.isPending||s.energy.current<=0} onClick={doTap} className="tap-target relative flex h-[330px] w-full max-w-[420px] items-end justify-center bg-transparent">{feedback.map(f=><span className="tap-number" key={f.id} style={{left:f.x,top:f.y}}>+{s.power}</span>)}<img className="mascot" src="/hamster-ceo.png" alt="Хомяк-директор в деловом костюме, очках и бабочке"/></button></div><div className="mt-3 text-center text-xs text-muted-foreground">Нажми на Бориса, чтобы пополнить казну</div></section>
   <div className="space-y-5"><section className="glass rounded-2xl p-5"><div className="mb-3 flex items-center justify-between"><span className="text-xs text-muted-foreground">Опыт до следующего уровня</span><span className="font-mono text-xs">{number(s.experience)} XP</span></div><div className="progress-track"><div className="progress-fill" style={{width:`${Math.min(100,s.experience%100)}%`}}/></div><div className="mt-4 grid grid-cols-2 gap-2"><Upgrade title="Мощный палец" text={`Сила тапа +1 · ${number(s.nextUpgradeCost)} монет`} icon={<Zap size={18}/>} disabled={s.balance<(s.nextUpgradeCost||Infinity)||upgrade.isPending} onClick={()=>upgrade.mutate({data:{kind:'tap-power'}},{onSuccess:()=>refresh()})}/><Upgrade title="Автодоход" text="Доход без остановки" icon={<Activity size={18}/>} disabled={upgrade.isPending} onClick={()=>upgrade.mutate({data:{kind:'passive-income'}},{onSuccess:()=>refresh()})}/></div></section>
    <section className="glass rounded-2xl p-5"><div className="mb-4 flex items-center justify-between"><h3 className="brand font-semibold">Задачи дня</h3><span className="text-[11px] text-violet-200">{s.missions.filter(m=>m.completed).length} из {s.missions.length}</span></div><div className="space-y-3">{s.missions.length===0?<Empty text="Новые задания скоро появятся"/>:s.missions.slice(0,4).map(m=><div key={m.id} className="rounded-xl bg-white/[.025] p-3" data-testid={`mission-${m.id}`}><div className="flex justify-between gap-2"><div><div className="text-sm font-medium">{m.title}</div><div className="mt-1 text-xs text-muted-foreground">{m.description}</div></div><span className="whitespace-nowrap text-xs text-amber-200">+{number(m.reward)}</span></div><div className="mt-3 flex items-center gap-3"><div className="progress-track flex-1"><div className="progress-fill" style={{width:`${Math.min(100,m.target?m.progress/m.target*100:0)}%`}}/></div><span className="text-[10px] text-muted-foreground">{number(m.progress)}/{number(m.target)}</span>{m.completed&&!m.claimed&&<button data-testid={`claim-mission-${m.id}`} className="text-xs font-semibold text-violet-200" onClick={()=>claim.mutate({missionId:m.id},{onSuccess:()=>refresh()})}>Забрать</button>}{m.claimed&&<Check size={14} className="text-emerald-300"/>}</div></div>)}</div></section></div>
  </div>
  <section className="glass mt-5 rounded-2xl p-5"><div className="mb-4 flex items-center gap-2"><Medal size={18} className="text-amber-200"/><h3 className="brand font-semibold">Достижения</h3></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{s.achievements.length===0?<Empty text="Достижения появятся по мере игры"/>:s.achievements.slice(0,6).map(a=><div className="rounded-xl border border-white/[.06] p-3" key={a.id}><div className="flex justify-between gap-2 text-sm font-medium"><span>{a.title}</span><span className={a.unlocked?'text-amber-200':'text-muted-foreground'}>+{number(a.reward)}</span></div><div className="mt-1 text-xs text-muted-foreground">{a.description}</div><div className="mt-3 progress-track"><div className="progress-fill" style={{width:`${Math.min(100,a.target?a.progress/a.target*100:0)}%`}}/></div></div>)}</div></section>
 </div>}</Shell>;
}
function Metric({label,value,icon,detail,highlight}:{label:string;value:string;icon:ReactNode;detail?:string;highlight?:boolean}) { return <div className={`glass rounded-2xl p-4 ${highlight?'border-amber-300/20':''}`}><div className="mb-3 flex items-center justify-between text-xs text-muted-foreground"><span>{label}</span><span className={highlight?'text-amber-200':'text-violet-200'}>{icon}</span></div><div className={`metric-value brand text-2xl font-bold ${highlight?'gold-text':''}`} data-testid={`metric-${label}`}>{value}</div>{detail&&<div className="mt-1 text-[10px] text-muted-foreground">{detail}</div>}</div>; }
function Upgrade({title,text,icon,onClick,disabled}:{title:string;text:string;icon:ReactNode;onClick:()=>void;disabled:boolean}) { return <button data-testid={`upgrade-${title}`} onClick={onClick} disabled={disabled} className="rounded-xl border border-violet-300/10 bg-violet-300/[.045] p-3 text-left transition hover:bg-violet-300/10 disabled:opacity-40"><span className="mb-2 block text-violet-200">{icon}</span><span className="block text-xs font-semibold">{title}</span><span className="mt-1 block text-[10px] leading-relaxed text-muted-foreground">{text}</span></button>; }
function Empty({text}:{text:string}) { return <div className="rounded-xl border border-dashed border-white/10 px-4 py-7 text-center text-xs text-muted-foreground">{text}</div>; }

function Shop() {
 const q=useGetShop();const qc=useQueryClient();const buy=usePurchaseCosmetic();const equip=useEquipCosmetic();const [filter,setFilter]=useState('Все');const [preview,setPreview]=useState<string|null>(null);const items=q.data?.items??[]; const cats=['Все','Фоны','Скины','Одежда','Аксессуары','Эффекты'];const catMap:Record<string,string[]>={'Одежда':['clothing'],'Скины':['color'],'Аксессуары':['glasses','hat','frame'],'Фоны':['background'],'Эффекты':['tap-effect','coin-animation']};const list=items.filter(i=>filter==='Все'||catMap[filter]?.includes(i.category));const refresh=()=>qc.invalidateQueries({queryKey:getGetShopQueryKey()});
  return <Shell><SectionTitle eyebrow="Лавка Бориса" title="Гардероб директора" desc="Собери образ, достойный совета директоров."/>{q.isLoading?<Loading/>:q.isError?<ErrorState retry={()=>q.refetch()}/>:<><div className="glass mb-5 flex flex-wrap items-center justify-between gap-4 rounded-2xl p-4"><div><div className="text-xs text-muted-foreground">Казна для покупок</div><div className="brand mt-1 text-xl font-bold gold-text">{number(q.data?.balance)} <span className="text-sm">монет</span></div></div><div className="mascot-stage flex h-24 w-24 items-center justify-center"><img className="mascot" src="/hamster-ceo.png" alt="Предпросмотр Бориса"/></div></div><div className="mb-5 flex gap-2 overflow-x-auto pb-1">{cats.map(c=><button key={c} onClick={()=>setFilter(c)} className={`whitespace-nowrap rounded-full px-4 py-2 text-xs ${filter===c?'bg-violet-500 text-white':'bg-white/[.06] text-muted-foreground'}`}>{c}</button>)}</div>{list.length===0?<Empty text="В этой категории пока нет предметов"/>:<div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{list.map(i=><article key={i.id} className={`glass rounded-2xl p-4 ${i.rarity==='legendary'?'rarity-legendary':''}`}><button onClick={()=>setPreview(preview===i.id?null:i.id)} className="flex h-32 w-full items-center justify-center rounded-xl bg-black/15 text-4xl" style={{color:i.color}} aria-label={`Предпросмотр ${i.name}`}><Sparkles size={38}/></button><div className="mt-4 flex items-start justify-between gap-2"><div><h3 className="font-semibold">{i.name}</h3><p className="mt-1 text-xs text-muted-foreground">{i.description}</p></div><span className="rounded-full bg-white/[.06] px-2 py-1 text-[9px] tracking-wider text-violet-200">{({common:'Обычный',rare:'Редкий',epic:'Эпический',legendary:'Легендарный'} as Record<string,string>)[i.rarity]}</span></div>{preview===i.id&&<div className="mt-3 rounded-lg bg-violet-400/10 p-2 text-xs text-violet-200">На Борисе: {i.name}</div>}<div className="mt-4 flex items-center justify-between gap-2"><span className="text-sm font-semibold text-amber-200">{i.vipOnly?'VIP':`${number(i.price)} монет`}</span>{i.equipped?<span className="flex items-center gap-1 text-xs text-emerald-300"><Check size={14}/> Надето</span>:i.owned?<Button testId={`equip-${i.id}`} disabled={equip.isPending} onClick={()=>equip.mutate({data:{itemId:i.id}},{onSuccess:refresh})}>Надеть</Button>:<Button testId={`buy-${i.id}`} disabled={i.vipOnly||buy.isPending||(q.data?.balance||0)<i.price} onClick={()=>buy.mutate({data:{itemId:i.id}},{onSuccess:refresh})}>{i.vipOnly?'Только VIP':<><ShoppingBag size={14} className="mr-1 inline"/>Купить</>}</Button>}</div></article>)}</div>}</>}</Shell>;
}

function Friends() {
  const q = useGetFriends();
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    if (!q.data?.referralLink) return;
    try {
      await navigator.clipboard.writeText(q.data.referralLink);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      window.prompt("Скопируй ссылку-приглашение", q.data.referralLink);
    }
  };

  return (
    <Shell>
      <SectionTitle
        eyebrow="Своя команда"
        title="Друзья и капитал"
        desc="Зови друзей в клуб — вместе быстрее к вершине."
      />
      {q.isLoading ? (
        <Loading />
      ) : q.isError ? (
        <ErrorState retry={() => q.refetch()} />
      ) : (
        <>
          <section className="glass wood-panel relative overflow-hidden rounded-3xl p-6 sm:p-9">
            <div className="relative z-10 max-w-xl">
              <div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-cyan-300/10 text-cyan-200">
                <Users />
              </div>
              <p className="text-xs font-bold uppercase tracking-[.18em] text-cyan-200">
                Закрытый клуб растёт
              </p>
              <h2 className="brand mt-2 text-3xl font-bold">
                Один друг — ещё один союзник
              </h2>
              <p className="mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                Поделись своей ссылкой. За приглашённых игроков начисляются
                награды и открываются новые рубежи.
              </p>
              <div className="mt-6 flex flex-col gap-2 sm:flex-row">
                <div className="flex min-w-0 flex-1 items-center rounded-xl border border-white/10 bg-black/20 px-3 text-xs text-muted-foreground">
                  <span className="truncate">{q.data?.referralLink}</span>
                </div>
                <Button
                  onClick={copy}
                  className="btn-primary inline-flex items-center justify-center gap-2"
                >
                  {copied ? <Check size={15} /> : <Send size={15} />}
                  {copied ? "Скопировано" : "Пригласить"}
                </Button>
              </div>
            </div>
            <div className="pointer-events-none absolute -right-4 -bottom-14 hidden text-[220px] font-bold text-violet-300/[.06] sm:block">
              HC
            </div>
          </section>

          <div className="my-5 grid grid-cols-2 gap-3">
            <Metric
              label="Приглашено"
              value={number(q.data?.invited)}
              icon={<Users />}
            />
            <Metric
              label="Заработано"
              value={number(q.data?.earned)}
              icon={<Coins />}
              highlight
            />
          </div>

          <section className="glass rounded-2xl p-5">
            <h3 className="brand mb-4 font-semibold">Рубежи команды</h3>
            <div className="space-y-3">
              {q.data?.milestones.length ? (
                q.data.milestones.map((m, i) => (
                  <div
                    className="flex items-center gap-3 rounded-xl border border-white/[.06] p-3"
                    key={m.id}
                  >
                    <span
                      className={`grid h-9 w-9 place-items-center rounded-xl ${m.completed ? "bg-emerald-400/10 text-emerald-300" : "bg-violet-400/10 text-violet-200"}`}
                    >
                      {m.completed ? (
                        <Check size={16} />
                      ) : (
                        <span className="text-xs">
                          {String(i + 1).padStart(2, "0")}
                        </span>
                      )}
                    </span>
                    <div className="flex-1">
                      <div className="text-sm font-medium">{m.title}</div>
                      <div className="text-xs text-muted-foreground">
                        Награда {number(m.reward)} монет
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {m.claimed
                        ? "Получено"
                        : m.completed
                          ? "Выполнено"
                          : "В процессе"}
                    </span>
                  </div>
                ))
              ) : (
                <Empty text="Рубежи появятся здесь" />
              )}
            </div>
          </section>

          <section className="glass mt-5 rounded-2xl p-5">
            <h3 className="brand mb-4 font-semibold">Твои приглашения</h3>
            {q.data?.referrals.length ? (
              q.data.referrals.map((r, i) => (
                <div
                  className="flex items-center justify-between border-t border-white/[.06] py-3"
                  key={`${r.displayName}-${i}`}
                >
                  <div>
                    <div className="text-sm">{r.displayName}</div>
                    <div className="text-xs text-muted-foreground">
                      С нами с {dates(r.joinedAt)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-violet-200">
                      {number(r.taps)} тапов
                    </div>
                    <div className="text-xs text-amber-200">
                      +{number(r.rewards)}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <Empty text="Пока нет приглашённых. Поделись ссылкой, чтобы собрать команду." />
            )}
          </section>
        </>
      )}
    </Shell>
  );
}

function Profile() {
 const q=useGetGameState();
 return <Shell><SectionTitle eyebrow="Личный кабинет" title="Профиль игрока" desc="Твой прогресс, достижения и статистика в клубе."/>
  {q.isLoading?<Loading label="Загружаем профиль"/>:q.isError||!q.data?<ErrorState retry={()=>q.refetch()}/>:<div className="appear space-y-5">
   <section className="glass wood-panel rounded-3xl p-6 sm:p-8"><div className="flex flex-wrap items-center justify-between gap-4"><div><p className="text-xs uppercase tracking-[.16em] text-violet-200">Игрок клуба</p><h2 className="brand mt-2 text-3xl font-bold">{q.data.player.displayName}</h2>{q.data.player.username&&<p className="mt-1 text-sm text-muted-foreground">@{q.data.player.username}</p>}</div><div className="rounded-2xl border border-amber-300/20 bg-amber-300/5 px-5 py-4 text-center"><Crown className="mx-auto text-amber-200" size={22}/><div className="brand mt-2 text-xl font-bold">{q.data.vip.active?'VIP':'Уровень '+q.data.level}</div>{q.data.vip.active&&<div className="mt-1 text-xs text-amber-100">до {dates(q.data.vip.expiresAt||'')}</div>}</div></div></section>
   <div className="grid grid-cols-2 gap-3 xl:grid-cols-4"><Metric label="Всего тапов" value={number(q.data.stats.totalTaps)} icon={<Zap/>}/><Metric label="Сегодня" value={number(q.data.stats.todayTaps)} icon={<Activity/>}/><Metric label="Заработано" value={number(q.data.stats.coinsEarned)} icon={<Coins/>} highlight/><Metric label="Место в рейтинге" value={`#${number(q.data.stats.rank)}`} icon={<Medal/>}/></div>
   <div className="grid gap-5 lg:grid-cols-2"><section className="glass rounded-2xl p-5"><h3 className="brand mb-4 font-semibold">Игровой прогресс</h3><div className="space-y-4"><div className="flex justify-between text-sm"><span className="text-muted-foreground">Уровень</span><strong>{number(q.data.level)}</strong></div><div className="flex justify-between text-sm"><span className="text-muted-foreground">Опыт</span><strong>{number(q.data.experience)} XP</strong></div><div className="flex justify-between text-sm"><span className="text-muted-foreground">Сила тапа</span><strong>+{number(q.data.power)} монет</strong></div><div className="flex justify-between text-sm"><span className="text-muted-foreground">Пассивный доход</span><strong>{number(q.data.passiveIncome)} / ч</strong></div><div className="flex justify-between text-sm"><span className="text-muted-foreground">Баланс</span><strong className="gold-text">{number(q.data.balance)} монет</strong></div></div></section>
    <section className="glass rounded-2xl p-5"><h3 className="brand mb-4 font-semibold">Достижения</h3><div className="space-y-3">{q.data.achievements.map(a=><div key={a.id} className="rounded-xl border border-white/[.06] p-3"><div className="flex justify-between gap-2 text-sm"><strong>{a.title}</strong><span className={a.unlocked?'text-amber-200':'text-muted-foreground'}>{a.unlocked?'Открыто':`${number(a.progress)} / ${number(a.target)}`}</span></div><p className="mt-1 text-xs text-muted-foreground">{a.description}</p></div>)}</div></section>
   </div>
  </div>}
 </Shell>;
}

function Contests() {
 const q=useGetContests();const join=useJoinContest();const qc=useQueryClient();
 const upcoming=(q.data??[]).filter(c=>c.status==='open'||c.status==='scheduled').sort((a,b)=>new Date(String(a.startsAt)).getTime()-new Date(String(b.startsAt)).getTime());
 return <Shell><SectionTitle eyebrow="Соревновательная лига" title="Конкурсы клуба" desc="Участвуй в испытаниях и забирай призы."/>
  {q.isLoading?<Loading/>:q.isError?<ErrorState retry={()=>q.refetch()}/>:<div className="space-y-6">
   <section className="glass rounded-2xl p-5 sm:p-6"><div className="mb-4 flex items-center gap-2"><CalendarDays size={18} className="text-violet-200"/><h2 className="brand font-semibold">Календарь конкурсов</h2></div>{upcoming.length?<div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">{upcoming.map(c=><div key={c.id} className="rounded-xl border border-white/[.07] bg-white/[.025] p-3"><p className="text-[11px] text-violet-200">{dates(c.startsAt)}</p><p className="mt-1 text-sm font-semibold">{c.title}</p><p className="mt-1 text-xs text-muted-foreground">{c.status==='open'?'Регистрация открыта':'Скоро'}</p></div>)}</div>:<p className="text-sm text-muted-foreground">Запланированных конкурсов пока нет.</p>}</section>
   {q.data?.length?<div className="space-y-4">{q.data.map(c=><ContestCard key={c.id} c={c} action={c.joined?'Участвуешь':c.status==='open'?'Вступить':c.vipOnly?'Только VIP':'Скоро'} busy={join.isPending} onAction={selectedOption=>join.mutate({contestId:c.id,data:selectedOption===undefined?undefined:{selectedOption}},{onSuccess:()=>qc.invalidateQueries({queryKey:getGetContestsQueryKey()})})}/>)}</div>:<div className="glass rounded-2xl p-10 text-center"><Swords size={30} className="mx-auto mb-3 text-violet-200"/><h3 className="font-semibold">Новых состязаний пока нет</h3><p className="mt-2 text-sm text-muted-foreground">Загляни позже — календарь клуба обновляется регулярно.</p></div>}
  </div>}
 </Shell>;
}
function ContestCard({c,action,busy,onAction}:{c:Contest;action:string;busy:boolean;onAction:(selectedOption?:number)=>void}) {
 const [selectedOption,setSelectedOption]=useState<number|undefined>(undefined);
 return <article className="glass overflow-hidden rounded-2xl"><div className="grid md:grid-cols-[220px_1fr]">{c.imageUrl?<img src={c.imageUrl} alt="" className="h-44 w-full object-cover md:h-full"/>:<div className="grid min-h-[150px] place-items-center bg-gradient-to-br from-violet-900/40 via-indigo-900/20 to-amber-900/20"><Swords size={40} className="text-violet-200/70"/></div>}<div className="p-5 sm:p-6"><div className="flex flex-wrap items-center gap-2"><span className="rounded-full bg-cyan-300/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-cyan-200">{contestTypes[c.type]||c.type}</span><span className="text-[11px] text-muted-foreground">{c.status==='open'?'Регистрация открыта':c.status==='scheduled'?'Предстоящий':c.status==='completed'?'Завершён':c.status}</span>{c.vipOnly&&<span className="rounded-full bg-amber-300/10 px-2 py-1 text-[10px] text-amber-200">VIP</span>}</div><h2 className="brand mt-3 text-xl font-semibold">{c.title}</h2><p className="mt-2 text-sm text-muted-foreground">{c.description}</p><div className="my-4 grid grid-cols-2 gap-3 text-xs"><div><div className="text-muted-foreground">Призовой фонд</div><div className="mt-1 font-semibold text-amber-200">{c.prize}</div></div><div><div className="text-muted-foreground">Старт конкурса</div><div className="mt-1">{dates(c.startsAt)}</div></div></div>{c.type==='quiz'&&!c.joined&&c.quizOptions?.length?<label className="mb-4 block text-xs text-muted-foreground">Выбери ответ<select className="mt-1 block w-full rounded-xl border border-white/10 bg-slate-950 p-3 text-sm text-white" value={selectedOption??''} onChange={event=>setSelectedOption(event.target.value===''?undefined:Number(event.target.value))}><option value="">Выбрать вариант</option>{c.quizOptions.map((option,index)=><option key={`${index}-${option}`} value={index}>{index+1}. {option}</option>)}</select></label>:null}<div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/[.07] pt-3"><div className="text-xs text-muted-foreground">{number(c.participants)} участников · {c.winnersCount} победителей {c.conditions&&<span className="block mt-1">{c.conditions}</span>}</div><Button testId={`join-${c.id}`} disabled={c.joined||c.status!=='open'||c.vipOnly||busy||(c.type==='quiz'&&selectedOption===undefined)} onClick={()=>onAction(selectedOption)} className={c.joined?'rounded-xl border border-emerald-300/20 px-4 py-2.5 text-sm text-emerald-200':'btn-primary rounded-xl px-4 py-2.5 text-sm'}>{c.joined?<><Check size={14} className="mr-1 inline"/>Участвуешь</>:action}</Button></div>{c.winners?.length? <div className="mt-4 text-xs text-muted-foreground">Победители: {c.winners.join(', ')}</div>:null}</div></div></article>;
}

function Vip() { const q=useGetGameState();const invoice=useCreateVipInvoice();return <Shell><SectionTitle eyebrow="Особый статус" title="Клуб VIP" desc="Больше возможностей для амбициозного хомяка."/><div className="glass wood-panel relative overflow-hidden rounded-3xl p-6 sm:p-10"><div className="absolute -right-10 -top-12 h-64 w-64 rounded-full bg-amber-300/[.07] blur-3xl"/><div className="relative grid gap-8 md:grid-cols-[1fr_320px]"><div><div className="inline-flex items-center gap-2 rounded-full border border-amber-300/25 bg-amber-300/10 px-3 py-1.5 text-xs text-amber-200"><Crown size={14}/> HAMSTER PRIVILEGE</div><h2 className="brand mt-5 text-4xl font-bold">Совсем другой<br/><span className="text-amber-200">уровень игры.</span></h2><p className="mt-4 max-w-lg text-sm leading-relaxed text-muted-foreground">VIP доступен на 30 дней. Оплата проходит через Telegram Stars, а статус подтверждается сервером.</p><div className="mt-7 space-y-4">{['Доступ к VIP-конкурсам клуба','Эксклюзивные предметы гардероба','Статус VIP в профиле игрока'].map((x,i)=><div className="flex items-center gap-3 text-sm" key={x}><span className="grid h-7 w-7 place-items-center rounded-full bg-amber-300/10 text-amber-200">{i+1}</span>{x}</div>)}</div></div><div className="glass self-center rounded-2xl p-6 text-center"><Star className="mx-auto text-amber-200" size={24}/><div className="brand mt-3 text-4xl font-bold">300</div><div className="text-xs uppercase tracking-[.18em] text-amber-200">Telegram Stars</div><div className="my-5 h-px bg-white/10"/><div className="text-sm">Полный доступ на <strong>30 дней</strong></div>{q.data?.vip.active&&<p className="mt-3 text-xs text-emerald-300">Активен до {dates(q.data.vip.expiresAt||'')}</p>}<Button testId="purchase-vip" disabled={invoice.isPending||q.data?.vip.active} onClick={()=>invoice.mutate(undefined,{onSuccess:r=>{window.location.assign(r.invoiceUrl)}})} className="btn-primary mt-6 flex w-full items-center justify-center gap-2">{invoice.isPending?<LoaderCircle className="animate-spin" size={16}/>:<Star size={15}/>} {q.data?.vip.active?'VIP уже активен':'Оформить на 30 дней'}</Button><p className="mt-3 text-[10px] leading-relaxed text-muted-foreground">Перед оплатой откроется подтверждение Telegram.</p></div></div></div><div className="mt-5 flex items-start gap-3 rounded-xl border border-white/[.07] bg-white/[.025] p-4 text-xs leading-relaxed text-muted-foreground"><ShieldCheck size={17} className="shrink-0 text-violet-200"/>VIP-покупка создаёт платёжный счёт Telegram. Сам статус включается только после успешного подтверждения оплаты.</div></Shell>}

const emptyContest:ContestInput={title:'',description:'',type:'random',prize:'',winnersCount:1,startsAt:'',endsAt:'',timeZone:'Europe/Warsaw',conditions:'',vipOnly:false,imageUrl:null};
function Admin() {
 const overview=useGetAdminOverview();const contests=useGetAdminContests();const cal=useGetContestCalendar();const qc=useQueryClient();const create=useCreateContest();const update=useUpdateContest();const action=useRunContestAction();const dayUpdate=useUpdateCalendarDay();const confirm=useConfirmContestSeries();const [draft,setDraft]=useState<ContestInput>(emptyContest);const [editId,setEditId]=useState<string|null>(null);const [day,setDay]=useState<CalendarEntry|null>(null);const [confirmOpen,setConfirmOpen]=useState(false);
 const reload=()=>{qc.invalidateQueries({queryKey:getGetAdminOverviewQueryKey()});qc.invalidateQueries({queryKey:getGetAdminContestsQueryKey()});qc.invalidateQueries({queryKey:getGetContestCalendarQueryKey()});qc.invalidateQueries({queryKey:getGetContestsQueryKey()});};
 if(overview.isLoading)return <Shell><SectionTitle eyebrow="Операционная панель" title="Администрирование" desc="Управление конкурсами и календарём публикаций."/><Loading/></Shell>;
 if(overview.isError||!overview.data)return <Shell><SectionTitle eyebrow="Ограниченный доступ" title="Администрирование" desc="Операционные инструменты доступны только администраторам."/><div className="glass rounded-2xl p-8 text-center"><LockKeyhole className="mx-auto mb-3 text-amber-200"/><h2 className="font-semibold">Нет доступа</h2><p className="mt-2 text-sm text-muted-foreground">Сервер не подтвердил права администратора. Управление публикациями скрыто.</p><Button onClick={()=>overview.refetch()} className="mt-5 inline-flex items-center gap-2"><RefreshCw size={15}/> Проверить доступ</Button></div></Shell>;
 const o=overview.data;const submit=()=>{const payload={...draft,winnersCount:Number(draft.winnersCount),imageUrl:draft.imageUrl||null};const done=()=>{reload();setDraft(emptyContest);setEditId(null)};editId?update.mutate({contestId:editId,data:payload},{onSuccess:done}):create.mutate({data:payload},{onSuccess:done})};
 const edit=(c:Contest)=>{setEditId(c.id);setDraft({title:c.title,description:c.description,type:c.type,prize:c.prize,winnersCount:c.winnersCount,startsAt:c.startsAt.slice(0,16),endsAt:c.endsAt.slice(0,16),timeZone:c.timeZone,conditions:c.conditions,vipOnly:c.vipOnly,imageUrl:c.imageUrl});window.scrollTo({top:0,behavior:'smooth'})};
 const run=(c:Contest,a:'publish'|'schedule'|'cancel'|'draw')=>{const scheduledAt=a==='schedule'?window.prompt('Дата и время публикации (ISO 8601)',c.startsAt):undefined;if(a==='schedule'&&!scheduledAt)return;if(window.confirm(`Подтвердить реальную операцию «${a}» для конкурса «${c.title}»?`))action.mutate({contestId:c.id,data:{action:a,...(scheduledAt?{scheduledAt}:{})}},{onSuccess:reload})};
 const saveDay=(entry:CalendarEntry)=>{const data:CalendarEntryUpdate={title:entry.title,description:entry.description,type:entry.type,conditions:entry.conditions,prize:entry.prize,winnersCount:Number(entry.winnersCount),publishAt:entry.publishAt,endsAt:entry.endsAt,timeZone:entry.timeZone,imageUrl:entry.imageUrl};dayUpdate.mutate({day:entry.day,data},{onSuccess:()=>{reload();setDay(null)}})};
 return <Shell><SectionTitle eyebrow="Операционная панель" title="Администрирование" desc="Черновики, публикации и 30-дневный календарь клуба."/>
  <div className="mb-5 grid grid-cols-2 gap-3 xl:grid-cols-4"><Metric label="Игроки" value={number(o.players)} icon={<Users/>}/><Metric label="Активные конкурсы" value={number(o.activeContests)} icon={<Swords/>}/><Metric label="Публикации в очереди" value={number(o.scheduledPosts)} icon={<CalendarDays/>}/><Metric label="Ждут розыгрыша" value={number(o.pendingDraws)} icon={<Award/>}/></div>
  <section className="glass mb-5 rounded-2xl p-5"><div className="flex flex-wrap items-center justify-between gap-4"><div><h2 className="brand font-semibold">Связь с Telegram</h2><p className="mt-1 text-xs text-muted-foreground">Проверка готовности бота и канала перед публикациями.</p></div><div className="flex flex-wrap gap-2">{[['Бот',o.telegramReady],['Канал',o.channelConfigured]].map(([name,ok])=><span key={String(name)} className={`rounded-full px-3 py-1.5 text-xs ${ok?'bg-emerald-300/10 text-emerald-200':'bg-rose-300/10 text-rose-200'}`}>{ok?'Готово':'Не настроено'} · {name}</span>)}</div></div>{o.botUsername&&<div className="mt-3 text-xs text-muted-foreground">Бот: @{o.botUsername}</div>}</section>
  <section className="glass mb-5 rounded-2xl p-5"><div className="mb-4 flex items-center justify-between gap-3"><div><h2 className="brand font-semibold">{editId?'Редактировать черновик':'Новый черновик конкурса'}</h2><p className="mt-1 text-xs text-muted-foreground">Сохранение создаёт только черновик. Публикация — отдельное подтверждаемое действие.</p></div>{editId&&<Button className="rounded-xl border border-white/10 px-3 py-2 text-xs text-muted-foreground" onClick={()=>{setEditId(null);setDraft(emptyContest)}}>Отмена</Button>}</div><div className="admin-grid">{([['Название','title'],['Приз','prize'],['Описание','description'],['Условия','conditions'],['Начало','startsAt'],['Окончание','endsAt'],['Часовой пояс','timeZone'],['URL изображения','imageUrl']] as const).map(([label,key])=><label key={key} className="text-xs text-muted-foreground">{label}{key==='description'||key==='conditions'?<textarea rows={2} value={draft[key]||''} onChange={e=>setDraft({...draft,[key]:e.target.value})}/>:<input type={key==='startsAt'||key==='endsAt'?'datetime-local':'text'} value={draft[key]||''} onChange={e=>setDraft({...draft,[key]:e.target.value})} placeholder={key==='imageUrl'?'https://…':''}/>}</label>)}<label className="text-xs text-muted-foreground">Тип конкурса<select value={draft.type} onChange={e=>setDraft({...draft,type:e.target.value as ContestInput['type']})}>{Object.entries(contestTypes).map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label><label className="text-xs text-muted-foreground">Количество победителей<input type="number" min="1" max="100" value={draft.winnersCount} onChange={e=>setDraft({...draft,winnersCount:Number(e.target.value)})}/></label><label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={draft.vipOnly} onChange={e=>setDraft({...draft,vipOnly:e.target.checked})} className="h-4 w-4"/> Только для VIP</label></div><Button testId="save-contest-draft" disabled={!draft.title||!draft.prize||!draft.startsAt||!draft.endsAt||create.isPending||update.isPending} onClick={submit} className="btn-primary mt-4 inline-flex items-center gap-2"><Check size={15}/>{editId?'Сохранить изменения':'Создать черновик'}</Button></section>
  <section className="glass mb-5 rounded-2xl p-5"><div className="mb-4 flex items-center justify-between"><div><h2 className="brand font-semibold">30-дневный календарь</h2><p className="mt-1 text-xs text-muted-foreground">Часовой пояс: {cal.data?.timeZone||'не указан'} · {cal.data?.entries.length||0} событий</p></div><Button testId="confirm-contest-series" disabled={Boolean(cal.data?.seriesConfirmed)||confirm.isPending} onClick={()=>setConfirmOpen(true)} className="btn-primary inline-flex items-center gap-2"><ShieldCheck size={15}/>{cal.data?.seriesConfirmed?'Серия подтверждена':'Запустить серию'}</Button></div>{cal.isLoading?<Loading/>:cal.isError?<ErrorState retry={()=>cal.refetch()}/>:<div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">{cal.data?.entries.map(entry=><div key={entry.day} className="rounded-xl border border-white/[.07] p-3"><div className="flex items-center justify-between"><span className="text-[10px] uppercase tracking-wider text-violet-200">День {entry.day} · {entry.status||'черновик'}</span><button data-testid={`edit-day-${entry.day}`} onClick={()=>setDay({...entry})} className="text-xs text-cyan-200">Изменить</button></div><div className="mt-2 text-sm font-medium">{entry.title}</div><div className="mt-1 text-xs text-muted-foreground">{dates(entry.publishAt)} · {entry.prize}</div></div>)}</div>}</section>
   <section className="glass rounded-2xl p-5"><h2 className="brand mb-4 font-semibold">Конкурсы и реальные действия</h2>{contests.isLoading?<Loading/>:contests.isError?<ErrorState retry={()=>contests.refetch()}/>:!contests.data?.length?<Empty text="Конкурсов пока нет. Создай первый черновик выше"/>:<div className="space-y-3">{contests.data.map(c=><div className="rounded-xl border border-white/[.07] p-4" key={c.id}><div className="flex flex-wrap items-start justify-between gap-3"><div><div className="flex items-center gap-2"><h3 className="font-semibold">{c.title}</h3><span className="rounded-full bg-white/[.07] px-2 py-1 text-[10px]">{c.status}</span></div><p className="mt-1 text-xs text-muted-foreground">{contestTypes[c.type]} · {dates(c.startsAt)} · {c.prize}</p><p className="mt-1 text-xs text-muted-foreground">Текст для публикации: {c.description}</p></div><div className="flex flex-wrap gap-2"><SmallAction label="Изменить" onClick={()=>edit(c)}/>{c.status==='draft'&&<SmallAction label="Запланировать" onClick={()=>run(c,'schedule')}/ >}{(c.status==='draft'||c.status==='scheduled')&&<SmallAction label="Опубликовать" onClick={()=>run(c,'publish')}/ >}{c.status==='open'&&<SmallAction label="Отменить" onClick={()=>run(c,'cancel')}/ >}{c.status==='open'&&<SmallAction label="Провести розыгрыш" onClick={()=>run(c,'draw')}/>}</div></div></div>)}</div>}</section>
   {confirmOpen&&<div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4"><div className="glass max-w-md rounded-2xl p-6"><ShieldCheck className="mb-3 text-amber-200"/><h2 className="brand text-xl font-semibold">Запустить первую серию?</h2><p className="mt-3 text-sm leading-relaxed text-muted-foreground">Подтверждение включает запланированные публикации 30-дневного календаря. Это реальное действие, которое отправит посты в Telegram. Проверь готовность бота и канала.</p>{!o.channelConfigured&&<p className="mt-3 rounded-lg border border-rose-300/20 bg-rose-300/5 p-3 text-xs leading-relaxed text-rose-200">Сначала добавь бота администратором канала и укажи TELEGRAM_CHANNEL_ID.</p>}<div className="mt-5 flex justify-end gap-2"><Button onClick={()=>setConfirmOpen(false)} className="rounded-xl border border-white/10 px-4 py-2.5 text-sm">Вернуться</Button><Button testId="confirm-series-final" disabled={!o.telegramReady||!o.channelConfigured||confirm.isPending} onClick={()=>confirm.mutate({data:{confirmed:true,timeZone:cal.data?.timeZone||'Europe/Warsaw'}},{onSuccess:()=>{setConfirmOpen(false);reload()}})} className="btn-primary">{confirm.isPending?'Подтверждение…':'Да, запустить серию'}</Button></div></div></div>}
  {day&&<div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-black/70 p-4"><div className="glass my-auto w-full max-w-xl rounded-2xl p-6"><h2 className="brand mb-4 text-xl font-semibold">День {day.day} · календарь публикаций</h2><div className="admin-grid">{([['Название','title'],['Приз','prize'],['Описание','description'],['Условия','conditions'],['Дата публикации','publishAt'],['Окончание','endsAt'],['Часовой пояс','timeZone'],['URL изображения','imageUrl']] as const).map(([label,key])=><label className="text-xs text-muted-foreground" key={key}>{label}{key==='description'||key==='conditions'?<textarea rows={2} value={day[key]||''} onChange={e=>setDay({...day,[key]:e.target.value})}/>:<input type={key==='publishAt'||key==='endsAt'?'datetime-local':'text'} value={key==='publishAt'||key==='endsAt'?day[key].slice(0,16):day[key]||''} onChange={e=>setDay({...day,[key]:e.target.value})}/>}</label>)}<label className="text-xs text-muted-foreground">Тип<select value={day.type} onChange={e=>setDay({...day,type:e.target.value as CalendarEntry['type']})}>{Object.entries(contestTypes).map(([v,l])=><option value={v} key={v}>{l}</option>)}</select></label><label className="text-xs text-muted-foreground">Победителей<input type="number" min="1" value={day.winnersCount} onChange={e=>setDay({...day,winnersCount:Number(e.target.value)})}/></label></div><div className="mt-5 flex justify-end gap-2"><Button onClick={()=>setDay(null)} className="rounded-xl border border-white/10 px-4 py-2.5 text-sm">Отмена</Button><Button disabled={dayUpdate.isPending} onClick={()=>saveDay(day)}>Сохранить день</Button></div></div></div>}
 </Shell>;
}
function SmallAction({label,onClick}:{label:string;onClick:()=>void}) { return <button onClick={onClick} className="rounded-lg border border-violet-300/15 bg-violet-300/[.05] px-3 py-2 text-[11px] font-semibold text-violet-100 hover:bg-violet-300/10">{label}</button>; }

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>\n      <Route path="/settings" component={Settings}/>
        <Route path="/" component={Home} />
        <Route path="/profile" component={Profile} />
        <Route path="/shop" component={Shop} />
        <Route path="/friends" component={Friends} />
        <Route path="/contests" component={Contests} />
        <Route path="/vip" component={Vip} />
        <Route path="/admin" component={Admin} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Settings() {
  return <Shell><SectionTitle eyebrow="Параметры игры" title="Настройки" desc="Настройки и информация о проекте."/>
    <section className="glass rounded-2xl p-5">
      <h2 className="mb-4 flex items-center gap-2 font-semibold"><ShieldCheck size={18}/> АДМИНЫ</h2>
      <div className="space-y-3 text-sm">
        <p><span className="text-muted-foreground">Тех админы</span><br/><span className="font-semibold">Crazy_Xdmm67</span></p>
        <p><span className="text-muted-foreground">Модератор</span><br/><span className="font-semibold">Crazy_Xdmm67</span></p>
        <p><span className="text-muted-foreground">Форум</span><br/><span className="font-semibold">Crazy_Xdmm67</span></p>
        <p><span className="text-muted-foreground">Менеджер</span><br/><span className="font-semibold">@bryson_ferrari</span></p>
      </div>
    </section>
  </Shell>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
