import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const hamsterPlayers = pgTable(
  "hamster_players",
  {
    telegramId: varchar("telegram_id", { length: 32 }).primaryKey(),
    username: varchar("username", { length: 64 }),
    firstName: varchar("first_name", { length: 128 }).notNull().default("Hamster"),
    lastName: varchar("last_name", { length: 128 }),
    coins: integer("coins").notNull().default(1000),
    energy: integer("energy").notNull().default(1000),
    energyUpdatedAt: timestamp("energy_updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    level: integer("level").notNull().default(1),
    experience: integer("experience").notNull().default(0),
    tapPower: integer("tap_power").notNull().default(1),
    passiveIncome: integer("passive_income").notNull().default(0),
    passiveRemainder: integer("passive_remainder").notNull().default(0),
    totalTaps: integer("total_taps").notNull().default(0),
    todayTaps: integer("today_taps").notNull().default(0),
    totalCoinsEarned: integer("total_coins_earned").notNull().default(0),
    todayDate: date("today_date", { mode: "string" }),
    lastTapAt: timestamp("last_tap_at", { withTimezone: true }),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    vipExpiresAt: timestamp("vip_expires_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("hamster_players_rank_idx").on(table.coins)],
);

export const insertHamsterPlayerSchema = createInsertSchema(hamsterPlayers).omit({
  createdAt: true,
});
export type HamsterPlayer = typeof hamsterPlayers.$inferSelect;
export type InsertHamsterPlayer = z.infer<typeof insertHamsterPlayerSchema>;

export const hamsterTaps = pgTable(
  "hamster_taps",
  {
    id: serial("id").primaryKey(),
    telegramId: varchar("telegram_id", { length: 32 })
      .notNull()
      .references(() => hamsterPlayers.telegramId, { onDelete: "cascade" }),
    requestId: varchar("request_id", { length: 80 }).notNull(),
    coinsEarned: integer("coins_earned").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("hamster_taps_player_request_uq").on(
      table.telegramId,
      table.requestId,
    ),
    index("hamster_taps_created_at_idx").on(table.createdAt),
  ],
);

export const hamsterMissionClaims = pgTable(
  "hamster_mission_claims",
  {
    id: serial("id").primaryKey(),
    telegramId: varchar("telegram_id", { length: 32 })
      .notNull()
      .references(() => hamsterPlayers.telegramId, { onDelete: "cascade" }),
    missionId: varchar("mission_id", { length: 80 }).notNull(),
    claimDate: date("claim_date", { mode: "string" }).notNull(),
    reward: integer("reward").notNull(),
    claimedAt: timestamp("claimed_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("hamster_mission_claim_once_uq").on(
      table.telegramId,
      table.missionId,
      table.claimDate,
    ),
  ],
);

export const hamsterInventory = pgTable(
  "hamster_inventory",
  {
    id: serial("id").primaryKey(),
    telegramId: varchar("telegram_id", { length: 32 })
      .notNull()
      .references(() => hamsterPlayers.telegramId, { onDelete: "cascade" }),
    itemId: varchar("item_id", { length: 80 }).notNull(),
    purchasedAt: timestamp("purchased_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("hamster_inventory_item_once_uq").on(
      table.telegramId,
      table.itemId,
    ),
  ],
);

export const hamsterEquipped = pgTable(
  "hamster_equipped",
  {
    telegramId: varchar("telegram_id", { length: 32 })
      .notNull()
      .references(() => hamsterPlayers.telegramId, { onDelete: "cascade" }),
    category: varchar("category", { length: 32 }).notNull(),
    itemId: varchar("item_id", { length: 80 }).notNull(),
    equippedAt: timestamp("equipped_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("hamster_equipped_slot_uq").on(table.telegramId, table.category),
  ],
);

export const hamsterReferrals = pgTable(
  "hamster_referrals",
  {
    id: serial("id").primaryKey(),
    inviterId: varchar("inviter_id", { length: 32 })
      .notNull()
      .references(() => hamsterPlayers.telegramId, { onDelete: "cascade" }),
    inviteeId: varchar("invitee_id", { length: 32 })
      .notNull()
      .references(() => hamsterPlayers.telegramId, { onDelete: "cascade" }),
    registrationRewardedAt: timestamp("registration_rewarded_at", {
      withTimezone: true,
    })
      .notNull()
      .defaultNow(),
    tapsRewardedAt: timestamp("taps_rewarded_at", { withTimezone: true }),
    returnRewardedAt: timestamp("return_rewarded_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("hamster_referral_invitee_uq").on(table.inviteeId),
    index("hamster_referral_inviter_idx").on(table.inviterId),
  ],
);

export const hamsterContests = pgTable(
  "hamster_contests",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    title: varchar("title", { length: 100 }).notNull(),
    description: text("description").notNull().default(""),
    type: varchar("type", { length: 24 }).notNull(),
    status: varchar("status", { length: 24 }).notNull().default("draft"),
    prize: varchar("prize", { length: 200 }).notNull(),
    winnersCount: integer("winners_count").notNull().default(1),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
    timeZone: varchar("time_zone", { length: 80 }).notNull(),
    conditions: text("conditions").notNull().default(""),
    vipOnly: boolean("vip_only").notNull().default(false),
    requiresSubscription: boolean("requires_subscription").notNull().default(false),
    quizQuestion: text("quiz_question"),
    quizOptions: jsonb("quiz_options")
      .$type<string[]>()
      .notNull()
      .default(sql`'[]'::jsonb`),
    quizCorrectOption: integer("quiz_correct_option"),
    imageUrl: text("image_url"),
    telegramMessageId: varchar("telegram_message_id", { length: 64 }),
    winners: jsonb("winners")
      .$type<string[]>()
      .notNull()
      .default(sql`'[]'::jsonb`),
    drawnAt: timestamp("drawn_at", { withTimezone: true }),
    lastError: text("last_error"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("hamster_contests_schedule_idx").on(table.status, table.startsAt),
    index("hamster_contests_end_idx").on(table.status, table.endsAt),
  ],
);

export const hamsterContestEntries = pgTable(
  "hamster_contest_entries",
  {
    id: serial("id").primaryKey(),
    contestId: uuid("contest_id")
      .notNull()
      .references(() => hamsterContests.id, { onDelete: "cascade" }),
    telegramId: varchar("telegram_id", { length: 32 })
      .notNull()
      .references(() => hamsterPlayers.telegramId, { onDelete: "cascade" }),
    selectedOption: integer("selected_option"),
    joinedAt: timestamp("joined_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("hamster_contest_entry_once_uq").on(
      table.contestId,
      table.telegramId,
    ),
  ],
);

export const hamsterCalendarEntries = pgTable("hamster_calendar_entries", {
  day: integer("day").primaryKey(),
  date: date("date", { mode: "string" }).notNull(),
  title: varchar("title", { length: 100 }).notNull(),
  description: text("description").notNull(),
  type: varchar("type", { length: 24 }).notNull(),
  conditions: text("conditions").notNull(),
  prize: varchar("prize", { length: 200 }).notNull(),
  winnersCount: integer("winners_count").notNull().default(1),
  publishAt: timestamp("publish_at", { withTimezone: true }).notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  timeZone: varchar("time_zone", { length: 80 }).notNull(),
  imageUrl: text("image_url"),
  requiresSubscription: boolean("requires_subscription").notNull().default(false),
  quizQuestion: text("quiz_question"),
  quizOptions: jsonb("quiz_options")
    .$type<string[]>()
    .notNull()
    .default(sql`'[]'::jsonb`),
  quizCorrectOption: integer("quiz_correct_option"),
  status: varchar("status", { length: 24 }).notNull().default("draft"),
  contestId: uuid("contest_id").references(() => hamsterContests.id, {
    onDelete: "set null",
  }),
});

export const hamsterAppSettings = pgTable("hamster_app_settings", {
  key: varchar("key", { length: 100 }).primaryKey(),
  value: jsonb("value").$type<unknown>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const hamsterStarPayments = pgTable(
  "hamster_star_payments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    telegramId: varchar("telegram_id", { length: 32 })
      .notNull()
      .references(() => hamsterPlayers.telegramId, { onDelete: "cascade" }),
    telegramChargeId: varchar("telegram_charge_id", { length: 128 })
      .notNull()
      .unique(),
    providerChargeId: varchar("provider_charge_id", { length: 128 }).notNull(),
    invoicePayload: varchar("invoice_payload", { length: 200 }).notNull(),
    amount: integer("amount").notNull(),
    currency: varchar("currency", { length: 8 }).notNull(),
    vipDays: integer("vip_days").notNull(),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    status: varchar("status", { length: 24 }).notNull().default("paid"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    refundedAt: timestamp("refunded_at", { withTimezone: true }),
  },
  (table) => [
    index("hamster_star_payments_player_idx").on(table.telegramId, table.createdAt),
  ],
);

export const insertHamsterContestSchema = createInsertSchema(hamsterContests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type HamsterContest = typeof hamsterContests.$inferSelect;
export type InsertHamsterContest = z.infer<typeof insertHamsterContestSchema>;
